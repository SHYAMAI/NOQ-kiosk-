# StoreKiosk
