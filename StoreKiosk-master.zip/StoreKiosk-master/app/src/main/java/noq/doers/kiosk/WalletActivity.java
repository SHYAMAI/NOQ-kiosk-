package noq.doers.kiosk;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import noq.doers.kiosk.Adapter.walletadapter;
import noq.doers.kiosk.DBModel.DB_USER;
import noq.doers.kiosk.Model.walletmodel;
import noq.doers.kiosk.utils.DBHelper;

public class WalletActivity extends AppCompatActivity {
    List<walletmodel> walletList;
    ProgressDialog dialog1;
    private ListView listView;
    private TextView WalletBalan,gotocart;
    private String CARD_ID;
    private String WALLET_AMT;
    private String USER_NAME;
    private String USER_MOBILE;
    private String USER_MAIL;
    private String USER_PIN,USERID,STORE_ID;
    private String CARTLIST;
private DBHelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);
        listView = findViewById(R.id.list_of_f);
        WalletBalan = findViewById(R.id.walletbaln);
        gotocart = findViewById(R.id.gohome);
        walletList = new ArrayList<>();
        mydb=new DBHelper(WalletActivity.this);
        DB_USER user = new DB_USER();
        user = mydb.getAllUsers();
        if(user.getMail()==null){
        }else{
            CARD_ID= user.getCard();
            WALLET_AMT= user.getWalletbalance();
            USER_NAME= user.getName();
            USER_MOBILE= user.getMobile();
            USER_MAIL= user.getMail();
            USER_PIN= user.getPin();
            USERID= String.valueOf(user.getUid());
            STORE_ID= String.valueOf(user.getStore_id());
        }
        gethistory(CARD_ID);
        gotocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent setIntent = new Intent(WalletActivity.this, HomeActivity.class);
                setIntent.putExtra("cartjson",CARTLIST);
//                setIntent.putExtra("cardid",String.valueOf(CARD_ID));
//                setIntent.putExtra("wallet",String.valueOf(WALLET_AMT));
//                setIntent.putExtra("username",USER_NAME);
//                setIntent.putExtra("usermail",String.valueOf(USER_MAIL));
//                setIntent.putExtra("usermobile",String.valueOf(USER_MOBILE));
//                setIntent.putExtra("userpin",USER_PIN);
//                setIntent.putExtra("userid",USERID);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            CARTLIST= "";
        } else {
            try{
                CARTLIST= extras.getString("cartjson");
//                CARD_ID= extras.getString("cardid");
//                WALLET_AMT= extras.getString("wallet");
//                USER_NAME= extras.getString("username");
//                USER_MOBILE= extras.getString("usermobile");
//                USER_MAIL= extras.getString("usermail");
//                USER_PIN= extras.getString("userpin");
//                USERID= extras.getString("userid");
//                gethistory(CARD_ID);
            }catch (Exception dd){
            }
        }
    }
    private void gethistory(String userid){
        dialog1 = ProgressDialog.show(WalletActivity.this, "Please Wait", "Please Wait...");
        HashMap<String , String> param = new HashMap<>();
        param.put("userid",userid);
        param.put("store_id",STORE_ID);
        // String o=globalValue.getString("barcode");
        System.out.println("Params:"+param);
        AndroidNetworking.post("http://noqapp.in/noq/prod/wallet/gethistorykiosk/")
                .addBodyParameter(param)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        walletList.clear();
                       try {
                           for (int i = 0; i < response.length(); i++) {
                               String closing_balance ,create_date,description,order_no,debit,credit;
                               JSONObject walletobj = response.getJSONObject(i);
                               if(i==0){
                                   WalletBalan.setText("\u20B9 "+walletobj.getString("closing_balance"));
                               }
                        if(walletobj.has("description")){
                            closing_balance = walletobj.getString("closing_balance");
                            create_date = walletobj.getString("create_date");
                            description = walletobj.getString("description");
                            if(walletobj.has("order_no")){
                                order_no = walletobj.getString("order_no");
                            }else{
                                order_no = "0";
                            }
                            debit = walletobj.getString("debit");
                            credit = walletobj.getString("credit");
                            walletList.add(new walletmodel(closing_balance,create_date,description,order_no,debit,credit));
                       }
                           }
                           walletadapter adapter = new walletadapter(WalletActivity.this, walletList);
                           listView.setAdapter(adapter);
                           dialog1.dismiss();
                       }catch(Exception dfs){
                           dialog1.dismiss();
                       }
                    }
                    @Override
                    public void onError(ANError anError) {
                        Log.e("IN","Error :"+anError.getErrorCode());
                        Log.e("IN","Error :"+anError.getErrorBody());
                        dialog1.dismiss();
                        Log.e("IN","Error :"+anError.getErrorDetail());
                        Toast.makeText(WalletActivity.this, "No Item Found . Scan Another Item", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
