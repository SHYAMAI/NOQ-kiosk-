package noq.doers.kiosk.Model;

public class ordermodel {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id,order_number,status,count,created_date,payment_type;

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public ordermodel(String id,String order_number, String status, String count, String created_date, String payment_type) {
        this.id = id;
        this.order_number = order_number;
        this.status = status;
        this.count = count;
        this.created_date = created_date;
        this.payment_type = payment_type;
    }

    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }



}
