package noq.doers.kiosk.DBModel;

import noq.doers.kiosk.Model.rfidlist;
import com.orm.SugarRecord;
import com.orm.dsl.Unique;

import java.util.List;

public class DB_CART extends SugarRecord {
    @Unique
    String product_id;
    String image,barcode,name,combo_id;
    String  price,selling_price,mrpqty,priceqty,taxper,QTY;


    // Default constructor is necessary for SugarRecord
    public DB_CART() {

    }

    public DB_CART(String image, String product_id, String barcode, String name, String combo_id, String price, String selling_price, String mrpqty, String priceqty, String taxper, String QTY) {
        this.image = image;
        this.name = name;
        this.product_id = product_id;
        this.barcode = barcode;
        this.combo_id = combo_id;
        this.price = price;
        this.selling_price = selling_price;
        this.mrpqty = mrpqty;
        this.priceqty = priceqty;
        this.taxper = taxper;
        this.QTY = QTY;
    }

    public String getQTY() {
        return QTY;
    }

    public void setQTY(String QTY) {
        this.QTY = QTY;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCombo_id() {
        return combo_id;
    }

    public void setCombo_id(String combo_id) {
        this.combo_id = combo_id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSelling_price() {
        return selling_price;
    }

    public void setSelling_price(String selling_price) {
        this.selling_price = selling_price;
    }

    public String getMrpqty() {
        return mrpqty;
    }

    public void setMrpqty(String mrpqty) {
        this.mrpqty = mrpqty;
    }

    public String getPriceqty() {
        return priceqty;
    }

    public void setPriceqty(String priceqty) {
        this.priceqty = priceqty;
    }

    public String getTaxper() {
        return taxper;
    }

    public void setTaxper(String taxper) {
        this.taxper = taxper;
    }
    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getImage() {
        return "http://noqapp.in/noq/store/"+image;
    }

    public String getName() {
        return name;
    }


}