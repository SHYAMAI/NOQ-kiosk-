package noq.doers.kiosk.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import noq.doers.kiosk.DBModel.DB_USER;

public class DBHelper extends SQLiteOpenHelper {


    public static final String DATABASE_NAME = "noqkiosk.db";
    public static final int DATABASE_VERSION = 3;
    //    private static final String TABLE_CUSTOMER = "customers";
    private static final String TABLE_USER = "users";
//
//    public static final String CUS_ID = "cid";
//    public static final String CUS_NAME = "cname";
//    public static final String CUS_MOBILE = "cmobile";
//    public static final String CUS_CARD = "ccard";
//    public static final String CUS_EMAIL = "cemail";
//    public static final String CUS_WALLET = "cwallet";

    public static final String USER_ID = "uid";
    public static final String USER_NAME = "uname";
    public static final String USER_MOBILE = "umobile";
    public static final String USER_EMAIL = "uemail";
    public static final String USER_CARD = "card";
    public static final String USER_BALANCE = "walletbalance";
    public static final String USER_PIN = "pin";
    public static final String STORE_ID = "store_id";


    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USER + "(" + USER_ID
            + " INTEGER PRIMARY KEY ," + USER_NAME + " TEXT," + USER_MOBILE + " TEXT ," + USER_EMAIL + " TEXT," + USER_CARD + " TEXT," + USER_BALANCE + " TEXT," + USER_PIN + " TEXT," + STORE_ID + " TEXT);";

//    private static final String CREATE_TABLE_CUSTOMER = "CREATE TABLE "
//            + TABLE_USER + "(" + CUS_ID
//            + " INTEGER PRIMARY KEY ," + CUS_NAME + " TEXT," + CUS_MOBILE + " TEXT ," + CUS_CARD + " TEXT," + CUS_EMAIL + " TEXT," + CUS_WALLET + " TEXT);";
//


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("table", CREATE_TABLE_USERS);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
//        db.execSQL(CREATE_TABLE_CUSTOMER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_USER + "'");
//        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_CUSTOMER + "'");
        onCreate(db);
    }

    public long addUser(Integer user_id, String user_name, String user_mobile,String user_mail,String user_balance,String user_card,String user_pin,String store_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //adding user name in users table
        ContentValues values = new ContentValues();
        values.put(USER_ID, user_id);
        values.put(USER_NAME, user_name);
        values.put(USER_MOBILE, user_mobile);
        values.put(USER_EMAIL, user_mail);
        values.put(USER_BALANCE, user_balance);
        values.put(USER_CARD, user_card);
        values.put(USER_PIN, user_pin);
        values.put(STORE_ID, store_id);
        // db.insert(TABLE_USER, null, values);
        long id = db.insertWithOnConflict(TABLE_USER, null, values, SQLiteDatabase.CONFLICT_IGNORE);
        return id;
    }

    public DB_USER getAllUsers() {
        DB_USER userModel = new DB_USER();

        String selectQuery = "SELECT  * FROM " + TABLE_USER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                userModel.setUid(c.getInt(c.getColumnIndex(USER_ID)));
                userModel.setName(c.getString(c.getColumnIndex(USER_NAME)));
                userModel.setMail(c.getString(c.getColumnIndex(USER_EMAIL)));
                userModel.setMobile(c.getString(c.getColumnIndex(USER_MOBILE)));
                userModel.setWalletbalance(c.getString(c.getColumnIndex(USER_BALANCE)));
                userModel.setCard(c.getString(c.getColumnIndex(USER_CARD)));
                userModel.setPin(c.getString(c.getColumnIndex(USER_PIN)));
                userModel.setStore_id(c.getString(c.getColumnIndex(STORE_ID)));

            } while (c.moveToNext());
        }
        return userModel;
    }

    public void updateUser(int id, String pin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_PIN, pin);
        db.update(TABLE_USER, values, USER_ID + "=" + id,null);
    }

    public void deleteUSer(int id) {

        // delete row in students table based on id
        SQLiteDatabase db = this.getWritableDatabase();

        //deleting from users table
        db.delete(TABLE_USER, USER_ID + " != ?",new String[]{"0"});


    }

}