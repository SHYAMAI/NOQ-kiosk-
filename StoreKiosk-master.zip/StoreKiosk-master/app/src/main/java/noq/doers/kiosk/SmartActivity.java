package noq.doers.kiosk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import noq.doers.kiosk.DBModel.DB_USER;
import noq.doers.kiosk.R;
import noq.doers.kiosk.utils.DBHelper;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SnapshotMetadata;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.uxcam.UXCam;
import com.zopim.android.sdk.api.ZopimChat;
import com.zopim.android.sdk.model.VisitorInfo;
import com.zopim.android.sdk.prechat.ZopimChatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

import static android.os.AsyncTask.THREAD_POOL_EXECUTOR;


public class SmartActivity extends AppCompatActivity {
   private EditText smartcode;
    private String WALLETAMOUNT;
    private String PIN,NAME,MAIL,MOBILE,USERID,STORE_ID;
    ProgressDialog Wallet_dialog;
    DBHelper mydb;
//    FirebaseFirestore Fbdb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart);
        UXCam.startWithKey("t7qjlho3ml7m7ha");
        UXCam.stopSessionAndUploadData();
        mydb=new DBHelper(SmartActivity.this);
        // Access a Cloud Firestore instance from your Activity
//        Fbdb = FirebaseFirestore.getInstance();
        smartcode =findViewById(R.id.smartcode);
        smartcode.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent keyevent) {
                //If the keyevent is a key-down event on the "enter" button
                if ((keyevent.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                  mydb.deleteUSer(0);
                  //  DB_USER.deleteAll(DB_USER.class);
//                    getWallet(smartcode.getText().toString());
//                    new Get_Wallet().execute(smartcode.getText().toString());
                    UXCam.startNewSession();
                    new Get_Wallet().executeOnExecutor(THREAD_POOL_EXECUTOR,smartcode.getText().toString());
                    return true;
                }
                return false;
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if ( smartcode!= null) {
                    Log.d("FOC","Set Focus");
                    smartcode.clearFocus();
                    smartcode.setText("");
                    smartcode.setFocusableInTouchMode(true);
                    smartcode.requestFocus();
                }
            }
        }, 0);
        smartcode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                // Check if no view has focus:
                if (v != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    assert imm != null;
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        });
//
//       try{
//
//           mydb.deleteUSer(0);
//        //   DB_USER.deleteAll(DB_USER.class);
//       }catch(Exception dfs){
//Log.i("",dfs.getMessage().toString());
//       }
//        mydb.deleteUSer(0);
//        UXCam.startNewSession();
//        new Get_Wallet().executeOnExecutor(THREAD_POOL_EXECUTOR,"284110099");
    }
    @SuppressLint("StaticFieldLeak")
    private class Get_Wallet extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Wallet_dialog = new ProgressDialog(SmartActivity.this);
            Wallet_dialog.setMessage("Please wait... Getting Customer Details...");
            Wallet_dialog.setIndeterminate(true);
            Wallet_dialog.setCancelable(false);
            Wallet_dialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
            final String Card=params[0];
            HashMap<String , String> param = new HashMap<>();
            param.put("cardid",Card);
            // String o=globalValue.getString("barcode");
            System.out.println("Params:"+param);
            AndroidNetworking.post("http://noqapp.in/noq/prod/customer/getaccesscodeuser/")
                    .addBodyParameter(param)
                                        .setPriority(Priority.MEDIUM)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            smartcode.setText("");
                            Log.e("IN","JSON :"+response.toString());
                            try {
                                WALLETAMOUNT= response.getString("wallet");
                                PIN= response.getString("pin");
                                NAME= response.getString("fullname");
                                MAIL= response.getString("email");
                                MOBILE= response.getString("mobile");
                                USERID= response.getString("id");
                                STORE_ID= response.getString("store_id");
                                if(USERID==null||USERID.contains("null")||USERID.contains("NULL")){
                                    AlertDialog.Builder invaliduser = new AlertDialog.Builder(SmartActivity.this);
                                    invaliduser.setMessage("Sorry There is Problem in Getting Customer Details,\n Please Try again")
                                            .setTitle("Alert")
                                            .setCancelable(false)
                                            .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    new Handler().postDelayed(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            if ( smartcode!= null) {
                                                                Log.d("FOC","Set Focus");
                                                                smartcode.setText("");
                                                                smartcode.setFocusableInTouchMode(true);
                                                                smartcode.requestFocus();
                                                            }
                                                        }
                                                    }, 0);
                                                }
                                            });
                                    //Creating dialog box
                                    AlertDialog alert = invaliduser.create();
                                    //Setting the title manually
                                    alert.show();
                                }else{
                                  //  mydb.add
                                   mydb.addUser(Integer.parseInt(USERID),NAME,MOBILE,MAIL,getdecimalformat(Double.valueOf(WALLETAMOUNT)),Card,PIN,STORE_ID);
                                  //  DB_USER user = new DB_USER(USERID,NAME,MOBILE,MAIL,Card,getdecimalformat(Double.valueOf(WALLETAMOUNT)),PIN,"user");
                                 //   user.save();
                                    // Create a new user with a first, middle, and last name
//                                    Fbdb.collection("users")
//                                            .get()
//                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//                                                @Override
//                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                                                    if (task.isSuccessful()) {
//                                                        for (QueryDocumentSnapshot document : task.getResult()) {
//                                                            Log.d("", document.getId() + " => " + document.getData());
//                                                            DocumentReference contact = Fbdb.collection("users").document(USERID);
//                                                            contact.update("user_name", "Testing")
//                                                                    .addOnSuccessListener(new OnSuccessListener < Void > () {
//                                                                        @Override
//                                                                        public void onSuccess(Void aVoid) {
//                                                                            Toast.makeText(SmartActivity.this, "Updated Successfully",
//                                                                                    Toast.LENGTH_SHORT).show();
//                                                                        }
//                                                                    });
//                                                        }
//                                                    } else {
//                                                        Log.w("", "Error getting documents.", task.getException());
//                                                    }
//                                                }
//                                            });
//                                    Map<String, Object> user = new HashMap<>();
//                                    user.put("user_id", USERID);
//                                    user.put("user_name", NAME);
//                                    user.put("user_mobile", MOBILE);
//                                    user.put("user_mail", MAIL);
//                                    user.put("user_balance", WALLETAMOUNT);
//                                    user.put("user_card", Card);
//                                    user.put("user_pin", PIN);
//                                    Fbdb.collection("users").document(USERID).set(user)
//                                            .addOnSuccessListener(new OnSuccessListener < Void > () {
//                                                @Override
//                                                public void onSuccess(Void aVoid) {
//                                                    Toast.makeText(SmartActivity.this, "User Registered",
//                                                            Toast.LENGTH_SHORT).show();
//                                                }
//                                            })
//                                            .addOnFailureListener(new OnFailureListener() {
//                                                @Override
//                                                public void onFailure(@NonNull Exception e) {
//                                                    Toast.makeText(SmartActivity.this, "ERROR" + e.toString(),
//                                                            Toast.LENGTH_SHORT).show();
//                                                    Log.d("TAG", e.toString());
//                                                }
//                                            });
                                    Intent setIntent = new Intent(SmartActivity.this, HomeActivity.class);
                                    setIntent.addCategory(Intent.CATEGORY_HOME);
                                    UXCam.setUserIdentity(NAME);
                                    UXCam.setUserProperty("CARD ID",Card);
                                    Map<String, String> articleParams = new HashMap<String, String>();
                                    articleParams.put("LOGIN_ID", Card);
                                    articleParams.put("USER_NAME", NAME);
                                    articleParams.put("STORE_ID", STORE_ID);
                                    articleParams.put("METHOD", "KIOSK");
//                                    UXCam.logEvent ("LOGIN", articleParams);
                                    log_Event log_Events = new log_Event();
                                    Gson gson = new Gson();
                                    String json = gson.toJson(articleParams);
                                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    String format = simpleDateFormat.format(new Date());
                                    Log.d("MainActivity", "Current Timestamp: " + format);
                                    HashMap<String , String> param = new HashMap<>();
                                    param.put("APP_ID","KIOSK");
                                    param.put("USER_ID",USERID);
                                    param.put("EVENT_NAME","LOGIN");
                                    param.put("STORE_ID", STORE_ID);
                                    param.put("EVENT_JSON",json);
                                    param.put("EVENT_TIME",format);
                                    log_Events.execute(param);
                                    startActivity(setIntent);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if ( smartcode!= null) {
                                            Log.d("FOC","Set Focus");
                                            smartcode.setText("");
                                            smartcode.setFocusableInTouchMode(true);
                                            smartcode.requestFocus();
                                        }
                                    }
                                }, 1000);
                            }
                            Wallet_dialog.dismiss();
                        }
                        @Override
                        public void onError(ANError anError) {
                            Wallet_dialog.dismiss();
                            Log.e("IN","Error :"+anError.getErrorCode());
                            Log.e("IN","Error :"+anError.getErrorBody());
                            Log.e("IN","Error :"+anError.getErrorDetail());
                            //Toast.makeText(AccessActivity.this, "No Item Found . Scan Another Item", Toast.LENGTH_SHORT).show();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (smartcode!= null) {
                                        Log.d("FOC","Set Focus");
                                        smartcode.setText("");
                                        smartcode.setFocusableInTouchMode(true);
                                        smartcode.requestFocus();
                                    }
                                }
                            }, 1000);
                        }
                    });
            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);
            Wallet_dialog.dismiss();
        }
    }

    private String getdecimalformat( Double val){
        int decimals = 2;
        BigDecimal value = new BigDecimal(val).setScale(decimals, RoundingMode.HALF_EVEN);
        return String.valueOf(value);
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(SmartActivity.this, "Sorry, Please Show Your Smart Card To Continue, Thank You !! ", Toast.LENGTH_SHORT).show();
        smartcode.setText("");
    }
}
