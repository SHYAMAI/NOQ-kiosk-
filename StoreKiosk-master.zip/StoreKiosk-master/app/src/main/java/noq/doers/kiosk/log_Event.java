package noq.doers.kiosk;

import android.os.AsyncTask;
import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONObject;
import java.util.Arrays;
import java.util.HashMap;

 class log_Event extends AsyncTask<HashMap<String , String>, String, String> {

    @SafeVarargs
    @Override
    protected final String doInBackground(HashMap<String , String>... param) {
        // String o=globalValue.getString("barcode");
        System.out.println("Params:"+ Arrays.toString(param));
        AndroidNetworking.post("http://noqapp.in/noq/prod/api/log_event/")
                 .addBodyParameter(param[0])
                .setPriority(Priority.LOW)
                .build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {
            }
            @Override
            public void onError(ANError anError) {
            }
        });
        return "";
    }
}