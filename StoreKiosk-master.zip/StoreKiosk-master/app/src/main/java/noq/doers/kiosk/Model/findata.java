package noq.doers.kiosk.Model;

import java.util.List;

public class findata {


    String store_id;
    String order_number;
    String customer_id;
    String tax_total;
    String discount_total;
    String grand_total;
    String sub_total;
    String advance_amount;
    String remaining_amount;
    String payment_log;
    String delivery_payment_log;
    String payment_status;
    String delivery_amount;
    String delivery_date;
    String delivery_time;
    String created_by;
    String invoice_status;
    String payment_type;
    List<ordata> order_items;
    String address_id;
    String mobilenum;

    public findata(String store_id,String order_number,String customer_id,String tax_total,String discount_total,String grand_total,String sub_total,String
            advance_amount,String remaining_amount,String payment_log,String delivery_payment_log,String payment_status,String delivery_amount,String delivery_date,String
            delivery_time,String created_by,String invoice_status,String payment_type,List<ordata> order_items,String address_id,String mobilenum) {


        this.store_id = store_id;
        this.order_number = order_number;
        this.customer_id = customer_id;
        this.tax_total = tax_total;
        this.discount_total = discount_total;
        this.grand_total = grand_total;
        this.sub_total = sub_total;
        this.advance_amount = advance_amount;
        this.remaining_amount = remaining_amount;
        this.payment_log = payment_log;
        this.delivery_payment_log = delivery_payment_log;
        this.payment_status = payment_status;
        this.delivery_amount = delivery_amount;
        this.delivery_date = delivery_date;
        this.delivery_time = delivery_time;
        this.created_by = created_by;
        this.invoice_status = invoice_status;
        this.payment_type = payment_type;
        this.order_items = order_items;
        this.address_id = address_id;
        this.mobilenum = mobilenum;
    }



    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getTax_total() {
        return tax_total;
    }

    public void setTax_total(String tax_total) {
        this.tax_total = tax_total;
    }

    public String getDiscount_total() {
        return discount_total;
    }

    public void setDiscount_total(String discount_total) {
        this.discount_total = discount_total;
    }

    public String getGrand_total() {
        return grand_total;
    }

    public void setGrand_total(String grand_total) {
        this.grand_total = grand_total;
    }

    public String getSub_total() {
        return sub_total;
    }

    public void setSub_total(String sub_total) {
        this.sub_total = sub_total;
    }

    public String getAdvance_amount() {
        return advance_amount;
    }

    public void setAdvance_amount(String advance_amount) {
        this.advance_amount = advance_amount;
    }

    public String getRemaining_amount() {
        return remaining_amount;
    }

    public void setRemaining_amount(String remaining_amount) {
        this.remaining_amount = remaining_amount;
    }

    public String getPayment_log() {
        return payment_log;
    }

    public void setPayment_log(String payment_log) {
        this.payment_log = payment_log;
    }

    public String getDelivery_payment_log() {
        return delivery_payment_log;
    }

    public void setDelivery_payment_log(String delivery_payment_log) {
        this.delivery_payment_log = delivery_payment_log;
    }

    public String getPayment_status() {
        return payment_status;
    }

    public void setPayment_status(String payment_status) {
        this.payment_status = payment_status;
    }

    public String getDelivery_amount() {
        return delivery_amount;
    }

    public void setDelivery_amount(String delivery_amount) {
        this.delivery_amount = delivery_amount;
    }

    public String getDelivery_date() {
        return delivery_date;
    }

    public void setDelivery_date(String delivery_date) {
        this.delivery_date = delivery_date;
    }

    public String getDelivery_time() {
        return delivery_time;
    }

    public void setDelivery_time(String delivery_time) {
        this.delivery_time = delivery_time;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getInvoice_status() {
        return invoice_status;
    }

    public void setInvoice_status(String invoice_status) {
        this.invoice_status = invoice_status;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public List<ordata> getOrder_items() {
        return order_items;
    }

    public void setOrder_items(List<ordata> order_items) {
        this.order_items = order_items;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getMobilenum() {
        return mobilenum;
    }

    public void setMobilenum(String mobilenum) {
        this.mobilenum = mobilenum;
    }




}