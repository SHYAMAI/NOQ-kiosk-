package noq.doers.kiosk.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class sessionUtil {


    private static SharedPreferences pref;
    private static SharedPreferences.Editor editor;
    private Context _context;
    private int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "Store";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";


    public sessionUtil(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public static void putString(final String key, final String value) {
        editor.putString(key, value);
        editor.commit();
    }

    public static String getString(final String key) {
        return pref.getString(key, null);
    }

    public static void putboolean(final String key, final boolean value) {
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static boolean getboolean(final String key) {
        return pref.getBoolean(key, false);
    }
    public static void ClearAll(){
        editor.clear();
        editor.commit();
    }

    public static void Clear(String key){
        editor.remove(key);
        editor.apply();
    }

}
