package noq.doers.kiosk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Paint;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;

import noq.doers.kiosk.Model.cartmodel;
import noq.doers.kiosk.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class cartadapter extends BaseAdapter {
    List<cartmodel> heroList;

    Context context;
    private static LayoutInflater inflater=null;
    public cartadapter(Context context, List<cartmodel> heroList) {
        // TODO Auto-generated constructor stub
        this.context = context;
        this.heroList = heroList;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return heroList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView prd_name,prd_mrp,prd_mrpqty,prd_selprice,prd_subtotal,prd_qty,prd_offerapplied;
        ImageView os_img;
        TableRow OfferLay;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView=convertView;

        if (rowView == null) {
            rowView = inflater.inflate(R.layout.cart_listitem, null);
            holder.prd_name =(TextView) rowView.findViewById(R.id.prd_name);
            holder.prd_mrp =(TextView) rowView.findViewById(R.id.prd_mrp);
            holder.prd_mrpqty =(TextView) rowView.findViewById(R.id.prd_mrpqty);
            holder.prd_selprice =(TextView) rowView.findViewById(R.id.prd_selprice);
            holder.OfferLay =(TableRow) rowView.findViewById(R.id.offerlay);
            holder.prd_subtotal =(TextView) rowView.findViewById(R.id.prd_subtotal);
            holder.prd_qty =(TextView) rowView.findViewById(R.id.prd_qty);
            holder.prd_offerapplied =(TextView) rowView.findViewById(R.id.prd_offerapplied);
            holder.os_img = rowView.findViewById(R.id.prd_image);
            rowView.setTag(holder);
        } else {
            holder = (Holder) rowView.getTag();
        }

        holder.OfferLay.setVisibility(View.GONE);
        //getting the hero of the specified position
        cartmodel hero = heroList.get(position);
        Log.i("hero",String.valueOf(hero.getPrice()));
        holder.prd_name.setText(hero.getName());
        holder.prd_mrp.setText("\u20B9"+String.valueOf(hero.getPrice()));
    holder.prd_mrp.setPaintFlags(holder.prd_mrp.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        holder.prd_mrpqty.setText("= \u20B9"+String.valueOf(hero.getMrpqty()));
        holder.prd_selprice.setText("\u20B9"+String.valueOf(hero.getSelling_price()));
        holder.prd_subtotal.setText("\u20B9"+String.valueOf(hero.getPriceqty()));
        holder.prd_qty.setText(String.valueOf(hero.getQTY()));
        if (Double.parseDouble(hero.getOfferid())>0){
            holder.OfferLay.setVisibility(View.VISIBLE);
            holder.prd_offerapplied.setText(String.valueOf(hero.getOffername()));
        }

        Picasso.get()
                .load(hero.getImage())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into( holder.os_img);

        return rowView;
    }

}