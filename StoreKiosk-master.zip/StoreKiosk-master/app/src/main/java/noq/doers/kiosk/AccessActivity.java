package noq.doers.kiosk;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import noq.doers.kiosk.DBModel.DB_USER;
import noq.doers.kiosk.Model.findata;
import noq.doers.kiosk.Model.ordata;
import noq.doers.kiosk.Model.rfidlist;
import noq.doers.kiosk.utils.DBHelper;

import com.eze.api.EzeAPI;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mukesh.OnOtpCompletionListener;
import com.mukesh.OtpView;
import com.uxcam.UXCam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;



public class AccessActivity extends AppCompatActivity implements  OnOtpCompletionListener {
    final Context context = this;

    ProgressDialog  dialog1;
    private OtpView otpView;
//    private TableLayout buttons;
    private Button CANCEL,GOTOCART,PAY;
private String CARTLIST;
private boolean usewallet=false;
private Double WALLETAMOUNT,PAYAMOUNT,PAYFINAL,taxtotal,amtonly;
private String ord_id,SavedAmt;
//private TextView walletamount;
    private int REQUEST_CODE_PERMISSIONS = 2002;
    AlertDialog.Builder builder,builder2,invalidpinbuilder;
    private final int REQUEST_CODE_INITIALIZE = 10001;
    private final int REQUEST_CODE_PREPARE = 10002;
    private final int REQUEST_CODE_WALLET_TXN = 10003;
    private final int REQUEST_CODE_CHEQUE_TXN = 10004;
    private final int REQUEST_CODE_SALE_TXN = 10006;
    private final int REQUEST_CODE_CASH_BACK_TXN = 10007;
    private final int REQUEST_CODE_CASH_AT_POS_TXN = 10008;
    private final int REQUEST_CODE_CASH_TXN = 10009;
    private final int REQUEST_CODE_SEARCH = 10010;
    private final int REQUEST_CODE_VOID = 10011;
    private final int REQUEST_CODE_ATTACH_SIGN = 10012;
    private final int REQUEST_CODE_UPDATE = 10013;
    private final int REQUEST_CODE_CLOSE = 10014;
    private final int REQUEST_CODE_GET_TXN_DETAIL = 10015;
    private final int REQUEST_CODE_GET_INCOMPLETE_TXN = 10016;
    private String strTxnId = null, emiID = null;
    private String PIN,NAME,MAIL,MOBILE,USERID,STORE_ID;
private RelativeLayout pinlay;
    String userEntered;
    String userPin="0";
    final int PIN_LENGTH = 4;
    boolean keyPadLockedFlag = false;
    Context appContext;
    TextView viewotp,username;
    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
//    Button button10;
//    Button buttonExit;
    Button buttonDelete;
//    ImageView backSpace;
    private String CARD_ID,PAYMODE;
Dialog epicDialog;
ImageView closePopupPositiveImg,closePopupnegativeImg;
private DBHelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        appContext = this;
        userEntered = "";
        PAYMODE="WALLET";
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
       WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_access);
        Log.i("dsdf","Entered Access");
//        buttons = findViewById(R.id.buttons);
        CANCEL = findViewById(R.id.cancelbtn);
       TextView ordref = findViewById(R.id.ordref);
        GOTOCART = findViewById(R.id.cartbtn);
//        walletamount = findViewById(R.id.walletamount);
        viewotp = findViewById(R.id.viewotp);
        PAY = findViewById(R.id.paybtn);
        pinlay = (RelativeLayout) findViewById(R.id.pinlay);
        username =  findViewById(R.id.username);
        PAY.setBackgroundColor(getResources().getColor(R.color.payclrdisabled));
        PAY.setEnabled(false);
        buttonDelete = (Button) findViewById(R.id.buttonDeleteBack);
        mydb=new DBHelper(AccessActivity.this);
        DB_USER user = new DB_USER();
        user = mydb.getAllUsers();
        if(user.getMail()==null){
        }else{
            CARD_ID= user.getCard();
            WALLETAMOUNT= Double.parseDouble(user.getWalletbalance());
            NAME= user.getName();
            MOBILE= user.getMobile();
            MAIL= user.getMail();
            PIN= user.getPin();
            USERID= String.valueOf(user.getUid());
            STORE_ID= String.valueOf(user.getStore_id());
        }
        buttonDelete.setOnClickListener(new View.OnClickListener() {
          public void onClick(View v) {
                if (keyPadLockedFlag)
                {
                    return;
                }
                if (userEntered.length()>0)
                {
                    userEntered = userEntered.substring(0,userEntered.length()-1);
                    viewotp.setText("");
                }
          }
        });
        View.OnClickListener pinButtonHandler = new View.OnClickListener() {
            public void onClick(View v) {
                if (keyPadLockedFlag)
                {
                    return;
                }
                Button pressedButton = (Button)v;
                if (userEntered.length()<PIN_LENGTH)
                {
                    userEntered = userEntered + pressedButton.getText();
                    Log.v("PinView", "User entered="+userEntered);
                    viewotp.setText(viewotp.getText().toString()+"*");
                    if (userEntered.length()==PIN_LENGTH)
                    {
                        if (userEntered.equals(userPin))
                        {
                            Log.v("PinView", "Correct PIN");
                            PAY.setBackgroundColor(getResources().getColor(R.color.payclrenabled));
                          UXCam.unOccludeSensitiveView(pinlay);
                            PAY.setEnabled(true);
                        }
                        else
                        {
                            keyPadLockedFlag = true;
                            invalidpinalert();
                        }
                    }
                }
                else
                {
                    viewotp.setText("");
                    userEntered = "";
                    userEntered = userEntered + pressedButton.getText();
                    Log.v("PinView", "User entered="+userEntered);
                    viewotp.setText("8");
                }
            }
        };
        button0 = (Button)findViewById(R.id.button0);
        //button0.setTypeface(xpressive);
        button0.setOnClickListener(pinButtonHandler);
        button1 = (Button)findViewById(R.id.button1);
        //button1.setTypeface(xpressive);
        button1.setOnClickListener(pinButtonHandler);
        button2 = (Button)findViewById(R.id.button2);
        //button2.setTypeface(xpressive);
        button2.setOnClickListener(pinButtonHandler);
        button3 = (Button)findViewById(R.id.button3);
        //button3.setTypeface(xpressive);
        button3.setOnClickListener(pinButtonHandler);
        button4 = (Button)findViewById(R.id.button4);
        //button4.setTypeface(xpressive);
        button4.setOnClickListener(pinButtonHandler);
        button5 = (Button)findViewById(R.id.button5);
        //button5.setTypeface(xpressive);
        button5.setOnClickListener(pinButtonHandler);
        button6 = (Button)findViewById(R.id.button6);
        //button6.setTypeface(xpressive);
        button6.setOnClickListener(pinButtonHandler);
        button7 = (Button)findViewById(R.id.button7);
        //button7.setTypeface(xpressive);
        button7.setOnClickListener(pinButtonHandler);
        button8 = (Button)findViewById(R.id.button8);
        //button8.setTypeface(xpressive);
        button8.setOnClickListener(pinButtonHandler);
        button9 = (Button)findViewById(R.id.button9);
        //button9.setTypeface(xpressive);
        button9.setOnClickListener(pinButtonHandler);
        buttonDelete = (Button)findViewById(R.id.buttonDeleteBack);
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            CARTLIST= "";
        } else {
            try{
                CARTLIST= extras.getString("cartjson");
                SavedAmt= extras.getString("savedamt");
                ord_id= extras.getString("ordid");
                PAYAMOUNT= Double.parseDouble(extras.getString("payamnt"));
                taxtotal=  Double.parseDouble(extras.getString("taxtotal"));
                amtonly=  Double.parseDouble(extras.getString("amtonly"));
                PAY.setText("PAY Rs. "+String.valueOf(PAYAMOUNT));
                ordref.setText("* Reference Id: "+ord_id);
                username.setText(NAME+" \nWallet Balance : Rs. "+String.valueOf(WALLETAMOUNT));
                userPin =PIN;
//                walletamount.setText(String.valueOf(WALLETAMOUNT));
                        Log.i("PINN",PIN);
            }catch (Exception dd){
                Map<String, String> articleParams2 = new HashMap<String, String>();
                articleParams2.put("FROM","PAYMENT_PAGE");
                articleParams2.put("ACTION","CUSTOMER_DETAILS_MISMATCH");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams2);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams2);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
            if(USERID==null||USERID.contains("null")||USERID.contains("NULL")){
                AlertDialog.Builder invaliduser = new AlertDialog.Builder(AccessActivity.this);
                invaliduser.setMessage("Sorry There is Problem in Getting Customer Details,\n Please Try again")
                        .setTitle("Alert")
                        .setCancelable(false)
                        .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Map<String, String> articleParams = new HashMap<String, String>();
                                articleParams.put("FROM","PAYMENT_PAGE");
                                articleParams.put("ACTION","CUSTOMER_DETAILS_MISMATCH");
                                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String format = simpleDateFormat.format(new Date());
                                Log.d("MainActivity", "Current Timestamp: " + format);
                                log_Event log_Events = new log_Event();
                                Gson gson = new Gson();
                                String json = gson.toJson(articleParams);
                                HashMap<String , String> param = new HashMap<>();
                                param.put("APP_ID","KIOSK");
                                param.put("USER_ID",USERID);
                                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                                param.put("EVENT_JSON",json);
                                param.put("EVENT_TIME",format);
                                log_Events.execute(param);   Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(setIntent);
                                finish();  }
                        });
                //Creating dialog box
                AlertDialog alert = invaliduser.create();
                //Setting the title manually
                alert.show();
            }
            Map<String, String> articleParams = new HashMap<String, String>();
            articleParams.put("NAME", "PAYMENT PAGE");
            articleParams.put("USER_NAME", NAME);
            articleParams.put("USER_ID", CARD_ID);
        }
        CANCEL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> articleParams = new HashMap<String, String>();
                articleParams.put("FROM","PAYMENT_PAGE");
                articleParams.put("ACTION","CANCEL_BUTTON_CLICKED");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        GOTOCART.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> articleParams = new HashMap<String, String>();
                articleParams.put("FROM","PAYMENT_PAGE");
                articleParams.put("ACTION","GOTO_CART_CLICKED");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        if(WALLETAMOUNT<=0){
            builder2 = new AlertDialog.Builder(this);
            builder2.setTitle("Payment Confirmation")
                    .setMessage("Insufficient Balance in Wallet . Are You Sure to Continue Using Debit / Credit Card")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            pinlay.setVisibility(View.INVISIBLE);
                            Map<String, String> articleParams = new HashMap<String, String>();
                            articleParams.put("TOTAL", PAYAMOUNT.toString());
                            articleParams.put("ORDER_ID",ord_id);
                            articleParams.put("MODE", "CARD");
//                            UXCam.logEvent("Start Checkout", articleParams);
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            String format = simpleDateFormat.format(new Date());
                            Log.d("MainActivity", "Current Timestamp: " + format);
                            log_Event log_Events = new log_Event();
                            Gson gson = new Gson();
                            String json = gson.toJson(articleParams);
                            HashMap<String , String> param = new HashMap<>();
                            param.put("APP_ID","KIOSK");
                            param.put("USER_ID",USERID);
                            param.put("EVENT_NAME","START_CHECKOUT");
                            param.put("STORE_ID", STORE_ID);
                            param.put("EVENT_JSON",json);
                            param.put("EVENT_TIME",format);
                            log_Events.execute(param);
                            doInitializeEzeTap();
                            doPrepareDeviceEzeTap();
                            PAYFINAL=PAYAMOUNT;
                            payamount(ord_id,PAYFINAL,"CARD");
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            //  Action for 'NO' Button
                            dialog.cancel();
                            Map<String, String> articleParams = new HashMap<String, String>();
                            articleParams.put("FROM","PAYMENT_PAGE");
                            articleParams.put("ACTION","LOW_BALANCE");
                            UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            String format = simpleDateFormat.format(new Date());
                            Log.d("MainActivity", "Current Timestamp: " + format);
                            log_Event log_Events = new log_Event();
                            Gson gson = new Gson();
                            String json = gson.toJson(articleParams);
                            HashMap<String , String> param = new HashMap<>();
                            param.put("APP_ID","KIOSK");
                            param.put("USER_ID",USERID);
                            param.put("EVENT_NAME","CANCEL_TRANSACTION");
                            param.put("EVENT_JSON",json);
                            param.put("EVENT_TIME",format);
                            log_Events.execute(param);
                            Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                            setIntent.putExtra("cartjson",CARTLIST);
                            setIntent.addCategory(Intent.CATEGORY_HOME);
                            setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(setIntent);
                            finish();
                        }
                    });
            //Creating dialog box
            AlertDialog alert = builder2.create();
            //Setting the title manually
            alert.show();
        }else{
            final Dialog dialog = new Dialog(context);
            dialog.setContentView(R.layout.paymentchoose);
            // set the custom dialog components - text, image and button
            TextView walletmessage = (TextView) dialog.findViewById(R.id.walletmessage);
            walletmessage.setText("You Have Rs."+WALLETAMOUNT+" in Your Noq Wallet.\n Choose payment Method");
            ImageView walletbtn = (ImageView) dialog.findViewById(R.id.walletbtn);
            ImageView debitbtn = (ImageView) dialog.findViewById(R.id.debitbtn);
            TextView smarttextbtn =  dialog.findViewById(R.id.smarttextbtn);
            TextView debittextbtn =  dialog.findViewById(R.id.debittextbtn);
            walletbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pinlay.setVisibility(View.VISIBLE);
                    UXCam.occludeSensitiveView(pinlay);
                    dialog.dismiss();
                }
            });
            smarttextbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pinlay.setVisibility(View.VISIBLE);
                    UXCam.occludeSensitiveView(pinlay);
                    dialog.dismiss();
                }
            });
            debitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pinlay.setVisibility(View.INVISIBLE);
                    UXCam.unOccludeSensitiveView(pinlay);
                    Map<String, String> articleParams = new HashMap<String, String>();
                    articleParams.put("TOTAL", PAYAMOUNT.toString());
                    articleParams.put("ORDER_ID",ord_id);
                    articleParams.put("MODE", "CARD");
//                    UXCam.logEvent("Start Checkout", articleParams);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String format = simpleDateFormat.format(new Date());
                    Log.d("MainActivity", "Current Timestamp: " + format);
                    log_Event log_Events = new log_Event();
                    Gson gson = new Gson();
                    String json = gson.toJson(articleParams);
                    HashMap<String , String> param = new HashMap<>();
                    param.put("APP_ID","KIOSK");
                    param.put("USER_ID",USERID);
                    param.put("STORE_ID", STORE_ID);
                    param.put("EVENT_NAME","START_CHECKOUT");
                    param.put("EVENT_JSON",json);
                    param.put("EVENT_TIME",format);
                    log_Events.execute(param);
                    doInitializeEzeTap();
                    doPrepareDeviceEzeTap();
                    PAYFINAL=PAYAMOUNT;
                    payamount(ord_id,PAYFINAL,"CARD");
                    dialog.dismiss();
                }
            });
            debittextbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pinlay.setVisibility(View.INVISIBLE);
                    UXCam.unOccludeSensitiveView(pinlay);
                    Map<String, String> articleParams = new HashMap<String, String>();
                    articleParams.put("TOTAL", PAYAMOUNT.toString());
                    articleParams.put("ORDER_ID",ord_id);
                    articleParams.put("MODE", "PARTIAL");
//                    UXCam.logEvent("Start Checkout", articleParams);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String format = simpleDateFormat.format(new Date());
                    Log.d("MainActivity", "Current Timestamp: " + format);
                    log_Event log_Events = new log_Event();
                    Gson gson = new Gson();
                    String json = gson.toJson(articleParams);
                    HashMap<String , String> param = new HashMap<>();
                    param.put("APP_ID","KIOSK");
                    param.put("STORE_ID", STORE_ID);
                    param.put("USER_ID",USERID);
                    param.put("EVENT_NAME","START_CHECKOUT");
                    param.put("EVENT_JSON",json);
                    param.put("EVENT_TIME",format);
                    log_Events.execute(param);
                    doInitializeEzeTap();
                    doPrepareDeviceEzeTap();
                    PAYFINAL=PAYAMOUNT;
                    payamount(ord_id,PAYFINAL,"CARD");
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
        PAY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PAY.setEnabled(false);
                PAY.setVisibility(View.INVISIBLE);
                if(WALLETAMOUNT<PAYAMOUNT){    // 150 < 200
                        builder2 = new AlertDialog.Builder(AccessActivity.this);
                        builder2.setTitle("Payment Confirmation")
                                .setMessage("Insufficient Balance in Wallet . Are You Sure to Continue Using Debit / Credit Card for Balance")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                        Log.d("sgd","PARTIAL");
                                        PAYFINAL = PAYAMOUNT-WALLETAMOUNT;  // 100 - 250   -150
                                        Map<String, String> articleParams = new HashMap<String, String>();
                                        articleParams.put("TOTAL", PAYAMOUNT.toString());
                                        articleParams.put("ORDER_ID",ord_id);
                                        articleParams.put("MODE", "PARTIAL");
//                                        UXCam.logEvent("Start Checkout", articleParams);
                                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        String format = simpleDateFormat.format(new Date());
                                        Log.d("MainActivity", "Current Timestamp: " + format);
                                        log_Event log_Events = new log_Event();
                                        Gson gson = new Gson();
                                        String json = gson.toJson(articleParams);
                                        HashMap<String , String> param = new HashMap<>();
                                        param.put("APP_ID","KIOSK");
                                        param.put("USER_ID",USERID);
                                        param.put("EVENT_NAME","START_CHECKOUT");
                                        param.put("STORE_ID", STORE_ID);
                                        param.put("EVENT_JSON",json);
                                        param.put("EVENT_TIME",format);
                                        log_Events.execute(param);
                                        doInitializeEzeTap();
                                        doPrepareDeviceEzeTap();
                                        payamount(ord_id,PAYFINAL,"PARTIAL");
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Action for 'NO' Button
                                        dialog.cancel();
                                        Map<String, String> articleParams = new HashMap<String, String>();
                                        articleParams.put("FROM","PAYMENT_PAGE");
                                        articleParams.put("ACTION","LOW_BALANCE");
                                        UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        String format = simpleDateFormat.format(new Date());
                                        Log.d("MainActivity", "Current Timestamp: " + format);
                                        log_Event log_Events = new log_Event();
                                        Gson gson = new Gson();
                                        String json = gson.toJson(articleParams);
                                        HashMap<String , String> param = new HashMap<>();
                                        param.put("APP_ID","KIOSK");
                                        param.put("USER_ID",USERID);
                                        param.put("EVENT_NAME","CANCEL_TRANSACTION");
                                        param.put("EVENT_JSON",json);
                                        param.put("EVENT_TIME",format);
                                        log_Events.execute(param);
                                        Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                                        setIntent.putExtra("cartjson",CARTLIST);
                                        setIntent.addCategory(Intent.CATEGORY_HOME);
                                        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        startActivity(setIntent);
                                        finish();
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = builder2.create();
                        //Setting the title manually
                        alert.show();


                    }else if(WALLETAMOUNT>=PAYAMOUNT) //1000 >= 250
                    {
                        Map<String, String> articleParams = new HashMap<String, String>();
                        articleParams.put("TOTAL", PAYAMOUNT.toString());
                        articleParams.put("ORDER_ID",ord_id);
                        articleParams.put("MODE", "FULL WALLET");
//                        UXCam.logEvent("Start Checkout", articleParams);
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String format = simpleDateFormat.format(new Date());
                        Log.d("MainActivity", "Current Timestamp: " + format);
                        log_Event log_Events = new log_Event();
                        Gson gson = new Gson();
                        String json = gson.toJson(articleParams);
                        HashMap<String , String> param = new HashMap<>();
                        param.put("APP_ID","KIOSK");
                        param.put("USER_ID",USERID);
                        param.put("EVENT_NAME","START_CHECKOUT");
                        param.put("STORE_ID", STORE_ID);
                        param.put("EVENT_JSON",json);
                        param.put("EVENT_TIME",format);
                        log_Events.execute(param);
                        PAYFINAL=PAYAMOUNT;
                        gotosucess("WALLET",ord_id,"WALLET");//
                        Log.d("sgd","FULL WALLET");
                    }
            }
        });
       // pinlay.setVisibility(View.GONE);




    }



    @SuppressLint("StaticFieldLeak")
    private class LockKeyPadOperation extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            for (int i = 0; i < 2; i++) {
                try {
                    Thread.sleep(0);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {

            //Roll over
            viewotp.setText("");


            userEntered = "";

            keyPadLockedFlag = false;
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }

    }    private void payamount(String ord_id,Double topay,String MODE){
        PAYMODE=MODE;
        openPaymentPayloadPopup(REQUEST_CODE_SALE_TXN);
      //  gotosucess("ONLINE",ord_id);
    }

    private void gotosucess(String Mode,String ord_id,String Response){

        JsonParser parser = new JsonParser();
        JsonArray paymentsArray = parser.parse(CARTLIST).getAsJsonArray();
        List<ordata> heroList = new ArrayList<>();
        List<rfidlist> rflist;
        for(int i = 0; i < paymentsArray.size(); i++) {
            JsonObject jsonobject = paymentsArray.get(i).getAsJsonObject();
            String image = jsonobject.get("image").getAsString();
            String product_id = jsonobject.get("product_id").getAsString();
            String barcode = jsonobject.get("barcode").getAsString();
            String name = jsonobject.get("name").getAsString();
            String combo_id = jsonobject.get("combo_id").getAsString();
            Double price = jsonobject.get("price").getAsDouble();
            Double selling_price = jsonobject.get("selling_price").getAsDouble();
            Double mrpqty = jsonobject.get("mrpqty").getAsDouble();
            Double priceqty = jsonobject.get("priceqty").getAsDouble();
            Double tax_per = jsonobject.get("taxper").getAsDouble();
            String quantity = jsonobject.get("QTY").getAsString();
            String offerid = jsonobject.get("offerid").getAsString();
            String offername = jsonobject.get("offername").getAsString();
            Double x = tax_per * mrpqty / (100 + tax_per);
            rflist = new ArrayList<>();
            JsonParser parser2 = new JsonParser();
            JsonArray paymentsArray2 = parser2.parse(String.valueOf(jsonobject.get("rflis").getAsJsonArray())).getAsJsonArray();
//            for (int j=0;j<rfarr.size();j++){
//                JsonObject jsonobject2 = rfarr.get(j).getAsJsonObject();
//                rflist.add(new rfidlist(jsonobject2.get("rfid_barcode").getAsString(),jsonobject2.get("rfid").getAsString()));
//
//            }
            for(int j = 0; j < paymentsArray2.size(); j++) {
                JsonObject jsonobject2 = paymentsArray2.get(j).getAsJsonObject();
                rflist.add(new rfidlist(jsonobject2.get("rfid_barcode").getAsString(),jsonobject2.get("rfid").getAsString()));
            }
            heroList.add(new ordata(product_id, barcode, quantity, String.valueOf(tax_per), String.valueOf(x), String.valueOf(mrpqty), rflist,offerid,offername));
        }
        List<findata> finlist = new ArrayList<>();
        finlist.add(new findata(STORE_ID,ord_id,CARD_ID,String.valueOf(taxtotal),"0",String.valueOf(PAYAMOUNT),String.valueOf(PAYAMOUNT-taxtotal),"0","0",Response,"-"
                ,"KIOSK","0","0","0",CARD_ID,"-",Mode,heroList,"-",MOBILE));
        Gson gson = new Gson();
        String json = gson.toJson(finlist);
        Log.d("FINA:",json);
        placeorder(json);

    }
    private void placeorder(final String data){

        dialog1 = ProgressDialog.show(AccessActivity.this, "Please Wait", "Please Wait...");
        HashMap<String , String> param = new HashMap<>();
        param.put("ord_data",data);
        // String o=globalValue.getString("barcode");
        System.out.println("Params:"+param);
        AndroidNetworking.post("http://noqapp.in/noq/prod/api/place_order_kiosk/")
                .addBodyParameter(param)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("IN","JSON :"+response.toString());
                        try {
                            if (response.getString("status").equalsIgnoreCase("true")){
                                Map<String, String> articleParams = new HashMap<String, String>();
                                articleParams.put("TOTAL", PAYAMOUNT.toString());
                                articleParams.put("ORDER_ID",ord_id);
                                articleParams.put("MODE", "KIOSK");
                                UXCam.logEvent("Purchase", articleParams);
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String format = simpleDateFormat.format(new Date());
                                Log.d("MainActivity", "Current Timestamp: " + format);
                                log_Event log_Events = new log_Event();
                                Gson gson = new Gson();
                                String json = gson.toJson(articleParams);
                                HashMap<String , String> param = new HashMap<>();
                                param.put("APP_ID","KIOSK");
                                param.put("USER_ID",USERID);
                                param.put("EVENT_NAME","PURCHASE");
                                param.put("STORE_ID", STORE_ID);
                                param.put("EVENT_JSON",json);
                                param.put("EVENT_TIME",format);
                                log_Events.execute(param);
                                showsuccess(response.getString("balance"));
                            }else {
                                showfailure();
                                Toast.makeText(AccessActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        dialog1.dismiss();
                    }
                    @Override
                    public void onError(ANError anError) {
                        dialog1.dismiss();
                        Log.e("IN","Error :"+anError.getErrorCode());
                        Log.e("IN","Error :"+anError.getErrorBody());
                        Log.e("IN","Error :"+anError.getErrorDetail());
                        Toast.makeText(AccessActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                        Map<String, String> articleParams = new HashMap<String, String>();
                        articleParams.put("FROM","PAYMENT_PAGE");
                        articleParams.put("ACTION",anError.getErrorDetail()+"_"+anError.getErrorBody());
                        UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String format = simpleDateFormat.format(new Date());
                        Log.d("MainActivity", "Current Timestamp: " + format);
                        log_Event log_Events = new log_Event();
                        Gson gson = new Gson();
                        String json = gson.toJson(articleParams);
                        HashMap<String , String> param = new HashMap<>();
                        param.put("APP_ID","KIOSK");
                        param.put("USER_ID",USERID);
                        param.put("EVENT_NAME","CANCEL_TRANSACTION");
                        param.put("EVENT_JSON",json);
                        param.put("EVENT_TIME",format);
                        log_Events.execute(param);
                        showfailure();
                    }
                });
    }
//
//    private void getWallet(String cardid){
//         dialog1 = ProgressDialog.show(AccessActivity.this, "Please Wait", "Please Wait...");
//        HashMap<String , String> param = new HashMap<>();
//        param.put("cardid",cardid);
//        // String o=globalValue.getString("barcode");
//        System.out.println("Params:"+param);
//        AndroidNetworking.post("http://noqapp.in/noq/prod/customer/getaccesscodeuser/")
//                .addBodyParameter(param)
//                .setPriority(Priority.MEDIUM)
//                .build()
//                .getAsJSONObject(new JSONObjectRequestListener() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        Log.e("IN","JSON :"+response.toString());
//                        try {
//                            WALLETAMOUNT= Double.parseDouble(response.getString("wallet"));
//                            PIN= response.getString("pin");
//                            NAME= response.getString("fullname");
//                            MAIL= response.getString("email");
//                            MOBILE= response.getString("mobile");
////                            walletamount.setText(String.valueOf(WALLETAMOUNT));
//                            userPin =PIN;
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                        dialog1.dismiss();
//
//                    }
//                    @Override
//                    public void onError(ANError anError) {
//                        dialog1.dismiss();
//                        Log.e("IN","Error :"+anError.getErrorCode());
//                        Log.e("IN","Error :"+anError.getErrorBody());
//                        Log.e("IN","Error :"+anError.getErrorDetail());
//                        //Toast.makeText(AccessActivity.this, "No Item Found . Scan Another Item", Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//    }
    @Override
    public void onOtpCompleted(String otp) {
        Log.d("onOtpCompleted=>", otp);
        // Check if no view has focus:
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (otp.equalsIgnoreCase(PIN)){
//            buttons.setVisibility(View.VISIBLE);
        }
    }

    /**
     * invoke to initialize the SDK with the merchant key and the device (card
     * reader) with bank keys
     */
    private void doInitializeEzeTap() {
        /**********************************************
         {
         "demoAppKey": "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28",
         "prodAppKey": "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28",
         "merchantName": "DOERS_TECH_ENTERPRISE_SOL",
         "userName": "7540042021",
         "currencyCode": "INR",
         "appMode": "DEMO",
         "captureSignature": "false",
         "prepareDevice": "false"
         }
         **********************************************/
        JSONObject jsonRequest = new JSONObject();
        try {
            jsonRequest.put("demoAppKey", "f826cfde-55b4-4893-8a9e-e2078306dcfb");
            jsonRequest.put("prodAppKey", "f826cfde-55b4-4893-8a9e-e2078306dcfb");
            jsonRequest.put("merchantName", "DOERS_TECH_ENTERPRISE_SOL");
            jsonRequest.put("userName", "7540042021");
            jsonRequest.put("currencyCode", "INR");
            jsonRequest.put("appMode", "PROD");
            jsonRequest.put("captureSignature", "false");
            jsonRequest.put("prepareDevice", "false");
            EzeAPI.initialize(this, REQUEST_CODE_INITIALIZE, jsonRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * optional mechanism to prepare a device for card transactions
     */
    private void doPrepareDeviceEzeTap() {
        EzeAPI.prepareDevice(this, REQUEST_CODE_PREPARE);
    }

    /**
     * Ability to take wallet transaction for Mobiquick, Freecharge, Novopay
     * etc.
     */
    private void doWalletTxn(JSONObject jsonRequest) {
        /*******************************************
         {
         "amount": "123",
         "options": {
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         }
         }
         *******************************************/
        EzeAPI.walletTransaction(AccessActivity.this, REQUEST_CODE_WALLET_TXN, jsonRequest);
    }

    /**
     * Records cheque transaction
     */
    private void doChequeTxn(JSONObject jsonRequest) {
        /*****************************************
         {
         "amount": "123",
         "options": {
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "cheque": {
         "chequeNumber": "1234",
         "bankCode": "1234",
         "bankName": "xyz",
         "bankAccountNo": "1234",
         "chequeDate": "YYYY-MM-DD"
         }
         }
         *****************************************/
        EzeAPI.chequeTransaction(this, REQUEST_CODE_CHEQUE_TXN, jsonRequest);
    }

    /**
     * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
     * transactions for Indian banks. Ability to perform EMI option.
     */
    private void doSaleTxn(JSONObject jsonRequest) {
        /******************************************
         {
         "amount": "123",
         "options": {
         "amountCashback": 0,
         "amountTip": 0,
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "mode": "SALE"
         }
         ******************************************/
        EzeAPI.cardTransaction(this, REQUEST_CODE_SALE_TXN, jsonRequest);
    }

    /**
     * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
     * transactions for Indian banks. Ability to perform cashback option.
     */
    private void doCashbackTxn(JSONObject jsonRequest) {
        /******************************************
         {
         "amount": "123",
         "options": {
         "amountCashback": 100,
         "amountTip": 0,
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "mode": "CASHBACK"
         }
         ******************************************/
        EzeAPI.cardTransaction(this, REQUEST_CODE_CASH_BACK_TXN, jsonRequest);
    }

    /**
     * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
     * transactions for Indian banks. Ability to perform cash@pos option.
     */
    private void doCashAtPosTxn(JSONObject jsonRequest) {
        /******************************************
         {
         "amount": "0",
         "options": {
         "amountCashback": 100,
         "amountTip": 0,
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "mode": "CASH@POS"
         }
         ******************************************/
        EzeAPI.cardTransaction(this, REQUEST_CODE_CASH_AT_POS_TXN, jsonRequest);
    }

    /**
     * Ability to record cash transaction
     */
    private void doCashTxn(JSONObject jsonRequest) {
        /******************************************
         {
         "amount": "123",
         "options": {
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         }
         }
         ******************************************/
        EzeAPI.cashTransaction(this, REQUEST_CODE_CASH_TXN, jsonRequest);
    }

    /**
     * search transactions for a merchant based on certain search parameters
     */
    private void doSearchTxn() {
        /*********************************
         {
         "agentName": "Demo User"
         }
         *********************************/
        JSONObject jsonRequest = new JSONObject();
        try {
            jsonRequest.put("agentName", "Enter your user name");
            EzeAPI.searchTransaction(this, REQUEST_CODE_SEARCH, jsonRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * Void transaction method is invoked to void a payment transaction
     */
    private void doVoidTxn() {
        if (isTransactionIdValid()) {
            EzeAPI.voidTransaction(this, REQUEST_CODE_VOID, strTxnId);// pass your transaction id value here
        } else
            displayToast("Inorrect txn Id, please make a Txn.");
    }

    /**
     * @param bitmap
     * @return
     */
    public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();
        return Base64.encodeToString(byteFormat, Base64.NO_WRAP);
    }

    /**
     * Use this operation to attach an e-signature from the customer for
     * payments
     */


    /**
     * Check For Updates method is only relevant in the Android platform. It is
     * invoked to check for any updates to the Android Service app.
     */
    private void doCheckUpdate() {
        EzeAPI.checkForUpdates(this, REQUEST_CODE_UPDATE);
    }

    /**
     * use this method to check the status of an incomplete transaction due to
     * timeouts, network errors etc.
     */
    private void doCheckIncompleteTxn() {
        EzeAPI.checkForIncompleteTransaction(this, REQUEST_CODE_GET_INCOMPLETE_TXN);
    }

    /**
     * Retrieve the details of a transaction given a transaction Id
     */


    /**
     * closes the connection with Ezetap server and shut down gracefully
     */
    private void doCloseEzetap() {
        EzeAPI.close(this, REQUEST_CODE_CLOSE);
    }

    /**
     * @param message
     *            message for Toast
     */
    private void displayToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        try {
            if (intent != null && intent.hasExtra("response")) {
//                Toast.makeText(this, intent.getStringExtra("response"), Toast.LENGTH_LONG).show();
                Log.d("SampleAppLogs", intent.getStringExtra("response"));
            }
            switch (requestCode) {
                case REQUEST_CODE_CASH_TXN:
                case REQUEST_CODE_CASH_BACK_TXN:
                case REQUEST_CODE_CASH_AT_POS_TXN:
                case REQUEST_CODE_WALLET_TXN:
                case REQUEST_CODE_SALE_TXN:

                    if (resultCode == RESULT_OK) {
                        JSONObject response = new JSONObject(intent.getStringExtra("response"));
                        response = response.getJSONObject("result");
                        response = response.getJSONObject("txn");
                        strTxnId = response.getString("txnId");
                        emiID = response.getString("emiId");
                        Map<String, String> articleParams = new HashMap<String, String>();
                        articleParams.put("TOTAL", PAYAMOUNT.toString());
                        articleParams.put("ORDER_ID",ord_id);
                        articleParams.put("MODE", "FULL WALLET");
//                        UXCam.logEvent("Start Checkout", articleParams);
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String format = simpleDateFormat.format(new Date());
                        Log.d("MainActivity", "Current Timestamp: " + format);
                        log_Event log_Events = new log_Event();
                        Gson gson = new Gson();
                        String json = gson.toJson(articleParams);
                        HashMap<String , String> param = new HashMap<>();
                        param.put("APP_ID","KIOSK");
                        param.put("USER_ID",USERID);
                        param.put("EVENT_NAME","START_CHECKOUT");
                        param.put("STORE_ID", STORE_ID);
                        param.put("EVENT_JSON",json);
                        param.put("EVENT_TIME",format);
                        log_Events.execute(param);
                        gotosucess(PAYMODE,ord_id,intent.getStringExtra("response"));

                    } else if (resultCode == RESULT_CANCELED) {
                        JSONObject response = new JSONObject(intent.getStringExtra("response"));
                        response = response.getJSONObject("error");
                        String errorCode = response.getString("code");
                        String errorMessage = response.getString("message");
                        showfailure();
//                        Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
//                        setIntent.putExtra("cartjson",CARTLIST);
//                        setIntent.addCategory(Intent.CATEGORY_HOME);
//                        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(setIntent);
//                        finish();
                    }

                    break;

                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * @return transaction id is valid
     */
    private boolean isTransactionIdValid() {
        if (strTxnId == null)
            return false;
        else
            return true;
    }


    private void openPaymentPayloadPopup(final int REQUEST_CODE) {
//		try {
//			LayoutInflater layoutInflater = LayoutInflater.from(EzeNativeSampleActivity.this);
//			final View customView = layoutInflater.inflate(R.layout.payment_payload_popup, null);
//			AlertDialog.Builder editCustomerPopup = new AlertDialog.Builder(EzeNativeSampleActivity.this);
//			editCustomerPopup.setCancelable(false);
//			editCustomerPopup.setView(customView);
//			final AlertDialog alertDialog = editCustomerPopup.create();
//			alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//			alertDialog.show();
//
//			Button cancelButton = (Button) customView.findViewById(R.id.cancel_button);
//			cancelButton.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					alertDialog.cancel();
//				}
//			});
//
//			final EditText customerNameEditText = (EditText) customView.findViewById(R.id.user_name);
//			final EditText emailIdEditText = (EditText) customView.findViewById(R.id.user_email);
//			final EditText mobileNumberEditText = (EditText) customView.findViewById(R.id.user_mobile);
//			final EditText orderNumberEditText = (EditText) customView.findViewById(R.id.order_number);
//			final EditText payableAmountEditText = (EditText) customView.findViewById(R.id.payable_amount);
//			final EditText cashBackAmountEditText = (EditText) customView.findViewById(R.id.cashback_amount);
//
//			Button confirmButton = (Button) customView.findViewById(R.id.confirm_button);
//			confirmButton.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					if (orderNumberEditText.getText().toString().equalsIgnoreCase("")
//							|| payableAmountEditText.getText().toString().equalsIgnoreCase("")) {
//						displayToast(mandatoryErrMsg);
//						return;
//					}
        try {
            JSONObject jsonRequest = new JSONObject();
            JSONObject jsonOptionalParams = new JSONObject();
            JSONObject jsonReferences = new JSONObject();
            JSONObject jsonCustomer = new JSONObject();

            //Amount (mandatory)
            jsonRequest.put("amount", PAYFINAL);

            // Building Customer Object(Optional)
            jsonCustomer.put("name", NAME);
            jsonCustomer.put("mobileNo", MOBILE);
            jsonCustomer.put("email", MAIL);
            jsonOptionalParams.put("customer", jsonCustomer);

            // Building References Object(Optional)
            // Additionally reference2 and reference3 can be used as well
            jsonReferences.put("reference1", ord_id);

            // Passing Additional References(Optional)
            // If reference1, reference2 & reference3 is insufficient then additionalReferences array can be used
            JSONArray array = new JSONArray();
            array.put("addRef_xx1");
            array.put("addRef_xx2");
            jsonReferences.put("additionalReferences", array);

            jsonOptionalParams.put("references", jsonReferences);

            // Building Optional params Object(Optional)
            //jsonOptionalParams.put("amountCashback", cashBackAmountEditText.getText().toString() + "");// Cannot

            // Tip (Optional)
            //jsonOptionalParams.put("amountTip", 0.00);

            // Pay to Account(Optional) - Used for Multi TID payments
            //jsonOptionalParams.put("payToAccount", "12322");

            //Additional Data(Optional) - Used to send any additional info
            //Rarely used and limited for Ezetap's internal use
            JSONObject addlData = new JSONObject();
            addlData.put("addl1", "addl1");
            addlData.put("addl2", "addl2");
            addlData.put("addl3", "addl3");
            //jsonOptionalParams.put("addlData", addlData);

            //Application Data(Optional) - Used to send any app info
            //Rarely used and limited for Ezetap's internal use
            JSONObject appData = new JSONObject();
            appData.put("app1", "app1");
            appData.put("app2", "app2");
            appData.put("app3", "app3");
            //jsonOptionalParams.put("appData", appData);

            // Building final optional params
            jsonRequest.put("options", jsonOptionalParams);


            switch (REQUEST_CODE) {
                case REQUEST_CODE_WALLET_TXN:
                    doWalletTxn(jsonRequest);
                    break;
                case REQUEST_CODE_CHEQUE_TXN:
                    // Building Cheque Object
                    JSONObject jsonCheque = new JSONObject();
                    jsonCheque.put("chequeNumber", "");
                    jsonCheque.put("bankCode", "");
                    jsonCheque.put("bankName", "");
                    jsonCheque.put("bankAccountNo", "");
                    jsonCheque.put("chequeDate", "");

                    jsonRequest.put("cheque", jsonCheque);

                    doChequeTxn(jsonRequest);
                    break;
                case REQUEST_CODE_SALE_TXN:
                    jsonRequest.put("mode", "SALE");//Card payment Mode(mandatory)
                    doSaleTxn(jsonRequest);
                    break;
                case REQUEST_CODE_CASH_BACK_TXN:
                    jsonRequest.put("mode", "CASHBACK");//Card payment Mode(mandatory)
                    doCashbackTxn(jsonRequest);
                    break;
                case REQUEST_CODE_CASH_AT_POS_TXN:
                    jsonRequest.put("mode", "CASH@POS");//Card payment Mode(mandatory)
                    doCashAtPosTxn(jsonRequest);
                    break;
                case REQUEST_CODE_CASH_TXN:
                    doCashTxn(jsonRequest);
                    break;
            }
//						alertDialog.cancel();
        } catch (Exception e) {
            e.printStackTrace();
        }
//				}
//			});
//			alertDialog.show();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
    }

    public void showsuccess(String balan){
        epicDialog = new Dialog(AccessActivity.this);
        epicDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        epicDialog.setCancelable(false);
        epicDialog.setContentView(R.layout.epic_popup_positive);
        TextView walbal = epicDialog.findViewById(R.id.walbal);
        final TextView contents = epicDialog.findViewById(R.id.contents);
        closePopupPositiveImg = epicDialog.findViewById(R.id.closepop);
        Button btnaccept = epicDialog.findViewById(R.id.btnaccept);
        walbal.setText("Wallet Balance: \u20B9"+balan);
        contents.setText("Your Order is Successfull. Thank You For Your Tremendous Support.\n This Window Will Close Automatically ");

        new CountDownTimer(8000, 1000) {

            public void onTick(long millisUntilFinished) {
                if(Double.parseDouble(SavedAmt)>0){
                    String text = "<font >Your Order is Successful. You Saved </font><bold><font color=\'#0F3117\'> \u20B9"+SavedAmt+" </font></bold> <font> in this order.\n This Window Will Close in "+  millisUntilFinished / 1000+" Seconds</font>";
                    contents.setText(Html.fromHtml(text));
                }else{
                    contents.setText("Your Order is Successful.Thank You For Your Tremendous Support.\n This Window Will Close in "+ millisUntilFinished / 1000+" Seconds");
                }

                //here you can have your logic to set text to edittext
            }

            public void onFinish() {
                Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }

        }.start();

        btnaccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
                epicDialog.dismiss();
            }
        });
        closePopupPositiveImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
                epicDialog.dismiss();
            }
        });
   epicDialog.show();
    }
    public void invalidpinalert(){
//        LayoutInflater factory = LayoutInflater.from(this);
//         View deleteDialogView = factory.inflate(R.layout.epic_popup_alert, null);
//        final AlertDialog epicDialog = new AlertDialog.Builder(this).create();
//        epicDialog.setView(deleteDialogView);
        epicDialog = new Dialog(AccessActivity.this);
        epicDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        epicDialog.setCancelable(false);
        epicDialog.setContentView(R.layout.epic_popup_alert);

       // epicDialog.setContentView(R.layout.epic_popup_alert);
        closePopupnegativeImg = epicDialog.findViewById(R.id.closepop);
       Button btntry = epicDialog.findViewById(R.id.btntry);
        btntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userEntered = "";
                viewotp.setText("");
                new LockKeyPadOperation().execute("");
                epicDialog.dismiss();
            }
        });
        closePopupnegativeImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userEntered = "";
                viewotp.setText("");
                new LockKeyPadOperation().execute("");
                epicDialog.dismiss();
            }
        });
        epicDialog.show();
    }

    public void showfailure(){
        epicDialog = new Dialog(AccessActivity.this);
        epicDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        epicDialog.setCancelable(false);
        epicDialog.setContentView(R.layout.epic_popup_negative);
        closePopupnegativeImg = epicDialog.findViewById(R.id.closepop);
        Button btntry = epicDialog.findViewById(R.id.btntry);

        new CountDownTimer(8000, 1000) {

            public void onTick(long millisUntilFinished) {
                //here you can have your logic to set text to edittext
            }

            public void onFinish() {
               try{

                   epicDialog.dismiss();
                   Map<String, String> articleParams = new HashMap<String, String>();
                   articleParams.put("FROM","PAYMENT_PAGE");
                   articleParams.put("ACTION","PLACE_ORDER_FAILED");
                   UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                   String format = simpleDateFormat.format(new Date());
                   Log.d("MainActivity", "Current Timestamp: " + format);
                   log_Event log_Events = new log_Event();
                   Gson gson = new Gson();
                   String json = gson.toJson(articleParams);
                   HashMap<String , String> param = new HashMap<>();
                   param.put("APP_ID","KIOSK");
                   param.put("USER_ID",USERID);
                   param.put("EVENT_NAME","CANCEL_TRANSACTION");
                   param.put("EVENT_JSON",json);
                   param.put("EVENT_TIME",format);
                   log_Events.execute(param);
                   Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                   setIntent.putExtra("cartjson",CARTLIST);
//                   setIntent.putExtra("cardid",String.valueOf(CARD_ID));
//                   setIntent.putExtra("wallet",String.valueOf(WALLETAMOUNT));
//                   setIntent.putExtra("username",NAME);
//                   setIntent.putExtra("usermail",String.valueOf(MAIL));
//                   setIntent.putExtra("usermobile",String.valueOf(MOBILE));
//                   setIntent.putExtra("userpin",PIN);
//                   setIntent.putExtra("userid",USERID);
                   setIntent.addCategory(Intent.CATEGORY_HOME);
                   setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                   startActivity(setIntent);
                   finish();

               }
               catch (Exception sdf){

               }
            }

        }.start();
        btntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                epicDialog.dismiss();
                Map<String, String> articleParams = new HashMap<String, String>();
                articleParams.put("FROM","PAYMENT_PAGE");
                articleParams.put("ACTION","PLACE_ORDER_FAILED");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                setIntent.putExtra("cartjson",CARTLIST);
//                setIntent.putExtra("cardid",String.valueOf(CARD_ID));
//                setIntent.putExtra("wallet",String.valueOf(WALLETAMOUNT));
//                setIntent.putExtra("username",NAME);
//                setIntent.putExtra("usermail",String.valueOf(MAIL));
//                setIntent.putExtra("usermobile",String.valueOf(MOBILE));
//                setIntent.putExtra("userpin",PIN);
//                setIntent.putExtra("userid",USERID);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        closePopupnegativeImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                epicDialog.dismiss();
                Map<String, String> articleParams = new HashMap<String, String>();
                articleParams.put("FROM","PAYMENT_PAGE");
                articleParams.put("ACTION","PLACE_ORDER_FAILED");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                Intent setIntent = new Intent(AccessActivity.this, HomeActivity.class);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                setIntent.putExtra("cartjson",CARTLIST);
//                setIntent.putExtra("cardid",String.valueOf(CARD_ID));
//                setIntent.putExtra("wallet",String.valueOf(WALLETAMOUNT));
//                setIntent.putExtra("username",NAME);
//                setIntent.putExtra("usermail",String.valueOf(MAIL));
//                setIntent.putExtra("usermobile",String.valueOf(MOBILE));
//                setIntent.putExtra("userpin",PIN);
//                setIntent.putExtra("userid",USERID);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();  }
        });
        epicDialog.show();
    }
    private int nDigitRandomNo(int digits){
        int max = (int) Math.pow(10,(digits)) - 1; //for digits =7, max will be 9999999
        int min = (int) Math.pow(10, digits-1); //for digits = 7, min will be 1000000
        int range = max-min; //This is 8999999
        Random r = new Random();
        int x = r.nextInt(range);// This will generate random integers in range 0 - 8999999
        int nDigitRandomNo = x+min; //Our random rumber will be any random number x + min
        return nDigitRandomNo;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Map<String, String> articleParams = new HashMap<String, String>();
        articleParams.put("FROM","PAYMENT_PAGE");
        articleParams.put("ACTION","BACK_PRESSED");
        UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simpleDateFormat.format(new Date());
        Log.d("MainActivity", "Current Timestamp: " + format);
        log_Event log_Events = new log_Event();
        Gson gson = new Gson();
        String json = gson.toJson(articleParams);
        HashMap<String , String> param = new HashMap<>();
        param.put("APP_ID","KIOSK");
        param.put("USER_ID",USERID);
        param.put("EVENT_NAME","CANCEL_TRANSACTION");
        param.put("EVENT_JSON",json);
        param.put("EVENT_TIME",format);
        log_Events.execute(param);
        Intent setIntent = new Intent(AccessActivity.this, SmartActivity.class);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(setIntent);
        finish();
    }


}
