package noq.doers.kiosk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import noq.doers.kiosk.Model.ordermodel;
import noq.doers.kiosk.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class orderadapter  extends BaseAdapter {
    List<ordermodel> orderList;

    Context context;
    private static LayoutInflater inflater=null;
    public orderadapter(Context context, List<ordermodel> orderList) {
        // TODO Auto-generated constructor stub
        this.context = context;
        this.orderList = orderList;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return orderList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView order_number,status,count,created_date,payment_type,ordid;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView=convertView;

        if (rowView == null) {
            rowView = inflater.inflate(R.layout.order_item, null);



            holder.order_number =(TextView) rowView.findViewById(R.id.orderid);
            holder.ordid =(TextView) rowView.findViewById(R.id.ordid);
            holder.count =(TextView) rowView.findViewById(R.id.ordercount);
            holder.created_date =(TextView) rowView.findViewById(R.id.orderdate);
            holder.payment_type =(TextView) rowView.findViewById(R.id.ordertype);
            holder.status =(TextView) rowView.findViewById(R.id.orderamount);

            rowView.setTag(holder);
        } else {
            holder = (Holder) rowView.getTag();
        }
        //getting the hero of the specified position
        ordermodel order = orderList.get(position);

         holder.order_number.setText("Order Id: "+order.getOrder_number());
         holder.ordid.setText(order.getId());
        holder.count.setText(order.getCount()+" Items");
        holder.created_date.setText(order.getCreated_date());
        holder.payment_type.setText(order.getPayment_type());
        holder.status.setText("\u20B9 "+order.getStatus());


        return rowView;
    }


}