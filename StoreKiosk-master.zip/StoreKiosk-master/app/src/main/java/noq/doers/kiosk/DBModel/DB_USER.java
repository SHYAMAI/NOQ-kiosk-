package noq.doers.kiosk.DBModel;

import com.orm.SugarRecord;
import com.orm.dsl.Unique;

public class DB_USER extends SugarRecord {
    @Unique
    int uid;
    String name;
    String mobile;
    String mail;
    String card;
    String walletbalance;
    String pin;
    String dummy;
    String store_id;

    // Default constructor is necessary for SugarRecord
    public DB_USER() {

    }



    public DB_USER(int uid, String name, String mobile, String mail, String card, String walletbalance, String pin, String dummy, String store_id) {
this.uid=uid;
this.name=name;
this.mobile=mobile;
this.mail=mail;
this.card=card;
this.walletbalance=walletbalance;
this.pin=pin;
this.dummy=dummy;
this.store_id=store_id;
    }
    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }
    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getWalletbalance() {
        return walletbalance;
    }

    public void setWalletbalance(String walletbalance) {
        this.walletbalance = walletbalance;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
    public String getDummy() {
        return dummy;
    }

    public void setDummy(String dummy) {
        this.dummy = dummy;
    }
}