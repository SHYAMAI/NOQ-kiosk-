package noq.doers.kiosk;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import noq.doers.kiosk.utils.sessionUtil;
import com.eze.api.EzeAPI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Payment_Activity extends AppCompatActivity  {
    ProgressDialog progressDialog;
    private ListView mListView;
    private Context mContext = this;
    Toolbar mToolbar;
    String itemid,itemname,qty,mrp,description,itemcode,barcodevalue,image_url,price,output_vat,vendor,item_url;
    Dialog scan_dialog;
    ImageView p_close,p_item_image;
    String scan_barcode_value;
    LinearLayout generate_bill,scan_layout,cash_layout,card_layout,online_layout;
    sessionUtil globalValue;
    TextView cash_text,card_text,online_text;
    private final int CHANGE_PASSWORD = 1011;
    Intent intent = null;

    private int REQUEST_CODE_PERMISSIONS = 2002;

    private final int REQUEST_CODE_INITIALIZE = 10001;
    private final int REQUEST_CODE_PREPARE = 10002;
    private final int REQUEST_CODE_WALLET_TXN = 10003;
    private final int REQUEST_CODE_CHEQUE_TXN = 10004;
    private final int REQUEST_CODE_SALE_TXN = 10006;
    private final int REQUEST_CODE_CASH_BACK_TXN = 10007;
    private final int REQUEST_CODE_CASH_AT_POS_TXN = 10008;
    private final int REQUEST_CODE_CASH_TXN = 10009;
    private final int REQUEST_CODE_SEARCH = 10010;
    private final int REQUEST_CODE_VOID = 10011;
    private final int REQUEST_CODE_ATTACH_SIGN = 10012;
    private final int REQUEST_CODE_UPDATE = 10013;
    private final int REQUEST_CODE_CLOSE = 10014;
    private final int REQUEST_CODE_GET_TXN_DETAIL = 10015;
    private final int REQUEST_CODE_GET_INCOMPLETE_TXN = 10016;
    private final int REQUEST_CODE_PAY = 10017;
    private final int REQUEST_CODE_UPI = 10018;
    private final int REQUEST_CODE_REMOTE_PAY = 10019;
    private final int REQUEST_CODE_QR_CODE_PAY = 10020;
    boolean navigationBarVisibility = true;
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
    @Override
    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent(Payment_Activity.this, HomeActivity.class);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(setIntent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_layout);
        globalValue=new sessionUtil(Payment_Activity.this);
        card_layout = (LinearLayout) findViewById(R.id.card);
        card_text = (TextView) findViewById(R.id.card_text);

        //Checkout = (ListView) findViewById(R.id.checkout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                actionBar.setTitle("ListView");
            }
        }

        card_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                card_text.setText("Processing..");
                globalValue.putString("mop","Card");
                doInitializeEzeTap();
               doPrepareDeviceEzeTap();
                openPaymentPayloadPopup(REQUEST_CODE_SALE_TXN);

            }
        });
    }

    private void doSaleTxn(JSONObject jsonRequest) {
        /******************************************
         {
         "amount": "123",
         "options": {
         "amountCashback": 0,
         "amountTip": 0,
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "mode": "SALE"
         }
         ******************************************/
        EzeAPI.cardTransaction(this, REQUEST_CODE_SALE_TXN, jsonRequest);
    }

    private void doInitializeEzeTap() {
        /**********************************************
         {
         "demoAppKey": "your demo app key",
         "prodAppKey": "your prod app key",
         "merchantName": "your merchant name",
         "userName": "your user name",
         "currencyCode": "INR",
         "appMode": "SANDBOX/PROD",
         "captureSignature": "true/false",
         "prepareDevice": "true/false"
         }
         **********************************************/
        JSONObject jsonRequest = new JSONObject();
        try {
            jsonRequest.put("demoAppKey", "f826cfde-55b4-4893-8a9e-e2078306dcfb");
            jsonRequest.put("prodAppKey", "f826cfde-55b4-4893-8a9e-e2078306dcfb");
            jsonRequest.put("merchantName", "DOERS TECH ENTERPRISE SOLUTIONS PVT LTD");
            jsonRequest.put("userName", "7540042021");
            jsonRequest.put("currencyCode", "INR");
            jsonRequest.put("appMode", "PROD");
            jsonRequest.put("captureSignature", "true");
            jsonRequest.put("prepareDevice", "false");
            EzeAPI.initialize(this, REQUEST_CODE_INITIALIZE, jsonRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        try {
            if (intent != null && intent.hasExtra("response")) {
                ///Toast.makeText(this, "divya", Toast.LENGTH_LONG).show();
//				String s[]=intent.getStringExtra("response").split(",");
//				String su=s[0]
//				if()
                //Toast.makeText(this, intent.getStringExtra("response"), Toast.LENGTH_LONG).show();
                Log.d("SampleAppLogs", intent.getStringExtra("response"));

                if(requestCode == REQUEST_CODE_INITIALIZE)
                {

                    //    openPaymentPayloadPopup(REQUEST_CODE_SALE_TXN);

                }
                if(requestCode == REQUEST_CODE_PREPARE)
                {
                    //sessionUtil.putString("prepare","success");
                    openPaymentPayloadPopup(REQUEST_CODE_SALE_TXN);
                }
                if(requestCode == REQUEST_CODE_SALE_TXN)
                {
                    String strTxnId;
                    try {
                        JSONObject response = new JSONObject(intent.getStringExtra("response"));
                        Log.d("SampleAppLogs1", intent.getStringExtra("response"));
                        response = response.getJSONObject("result");
                        response = response.getJSONObject("txn");
                        strTxnId = response.getString("txnId");


                        try{
                            if (strTxnId.length()<=0||strTxnId==null||strTxnId.isEmpty()){

                                card_text.setText("Card");
                                Toast.makeText(mContext, "Invalid Transaction", Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(mContext, "SUCCESS Transaction", Toast.LENGTH_SHORT).show();
//                                Intent pay = new Intent(Payment_Activity.this, PrintBill_Activity.class);
//                                globalValue.putString("mop","Card");
//                                globalValue.putString("reference_number", strTxnId);
//                                startActivity(pay);
//                                finish();
                            }

                        }catch (Exception dsf){

                            AlertDialog.Builder builder;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                            } else {
                                builder = new AlertDialog.Builder(Payment_Activity.this);
                            }
                            builder.setTitle("Payment Failed")
                                    .setMessage("Invalid Transaction \nKindly try Again")
                                    .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                            startActivity(pay);
                                            finish();
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            // do nothing
                                            Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                            startActivity(pay);
                                            finish();
                                        }
                                    })
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();

                            Toast.makeText(mContext, "Invalid Transaction\n"+dsf.getMessage(), Toast.LENGTH_SHORT).show();
                            card_text.setText("Card");
                        }



                    }catch (Exception dsfs){
                        AlertDialog.Builder builder;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                        } else {
                            builder = new AlertDialog.Builder(Payment_Activity.this);
                        }
                        builder.setTitle("Payment Failed")
                                .setMessage("Invalid Transaction \nKindly try Again")
                                .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                        startActivity(pay);
                                        finish();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // do nothing
                                        Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                        startActivity(pay);
                                        finish();
                                    }
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                        Toast.makeText(mContext, "Invalid Transaction\n"+dsfs.getMessage(), Toast.LENGTH_SHORT).show();
                        card_text.setText("Card");


                    }



//                    Intent pay = new Intent(Payment_Activity.this, PrintBill_Activity.class);
////
//                    globalValue.putString("mop","Card");
//                    startActivity(pay);
//                    finish();

                    // send(intent.getStringExtra("response"));


//                    Toast.makeText(this, "Payment failed: " + Errorcode + " " + Errormsg, Toast.LENGTH_SHORT).show();
//
                }
            }
            switch (requestCode) {
                case REQUEST_CODE_UPI:
                case REQUEST_CODE_CASH_TXN:
                case REQUEST_CODE_CASH_BACK_TXN:
                case REQUEST_CODE_CASH_AT_POS_TXN:
                case REQUEST_CODE_WALLET_TXN:
                case REQUEST_CODE_SALE_TXN:

                    if (resultCode == RESULT_OK) {

                        String strTxnId;
                        try {
                            JSONObject response = new JSONObject(intent.getStringExtra("response"));
                            Log.d("SampleAppLogs1", intent.getStringExtra("response"));
                            response = response.getJSONObject("result");
                            response = response.getJSONObject("txn");
                            strTxnId = response.getString("txnId");
                            try{
                                if (strTxnId.length()<=0||strTxnId==null||strTxnId.isEmpty()){
                                    AlertDialog.Builder builder;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                        builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                                    } else {
                                        builder = new AlertDialog.Builder(Payment_Activity.this);
                                    }
                                    builder.setTitle("Payment Failed")
                                            .setMessage("Invalid Transaction \nKindly try Again")
                                            .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                                    startActivity(pay);
                                                    finish();
                                                }
                                            })
                                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    // do nothing
                                                    Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                                    startActivity(pay);
                                                    finish();
                                                }
                                            })
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                                    Toast.makeText(mContext, "Invalid Transaction", Toast.LENGTH_SHORT).show();
                                    card_text.setText("Card");
                                }else{
                                    Toast.makeText(mContext, "SUCCES Transaction", Toast.LENGTH_SHORT).show();

//                                    Intent pay = new Intent(Payment_Activity.this, PrintBill_Activity.class);
//                                    globalValue.putString("mop","Card");
//                                    globalValue.putString("reference_number", strTxnId);
//                                    startActivity(pay);
//                                    finish();
                                }
                            }catch (Exception dsf){
                                AlertDialog.Builder builder;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                                } else {
                                    builder = new AlertDialog.Builder(Payment_Activity.this);
                                }
                                builder.setTitle("Payment Failed")
                                        .setMessage("Invalid Transaction \nKindly try Again")
                                        .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                                startActivity(pay);
                                                finish();
                                            }
                                        })
                                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                // do nothing
                                                Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                                startActivity(pay);
                                                finish();
                                            }
                                        })
                                        .setIcon(android.R.drawable.ic_dialog_alert)
                                        .show();
                                Toast.makeText(mContext, "Invalid Transaction\n"+dsf.getMessage(), Toast.LENGTH_SHORT).show();
                                card_text.setText("Card");
                            }
                        }catch (Exception dsfs){
                            AlertDialog.Builder builder;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                            } else {
                                builder = new AlertDialog.Builder(Payment_Activity.this);
                            }
                            builder.setTitle("Payment Failed")
                                    .setMessage("Invalid Transaction \nKindly try Again")
                                    .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                            startActivity(pay);
                                            finish();
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            // do nothing
                                            Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                            startActivity(pay);
                                            finish();
                                        }
                                    })
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();
                            Toast.makeText(mContext, "Invalid Transaction\n"+dsfs.getMessage(), Toast.LENGTH_SHORT).show();
                            card_text.setText("Card");
                        }
                    } else if (resultCode == RESULT_CANCELED) {
                        JSONObject response = new JSONObject(intent.getStringExtra("response"));
                        Log.d("SampleAppLogs2", intent.getStringExtra("response"));
                        response = response.getJSONObject("error");
                        String errorCode = response.getString("code");
                        String errorMessage = response.getString("message");
                        //	send(intent.getStringExtra("response"));
                        AlertDialog.Builder builder;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            builder = new AlertDialog.Builder(Payment_Activity.this, android.R.style.Theme_Material_Dialog_Alert);
                        } else {
                            builder = new AlertDialog.Builder(Payment_Activity.this);
                        }
                        builder.setTitle("Payment Failed")
                                .setMessage("Invalid Transaction \nKindly try Again")
                                .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent pay = new Intent(Payment_Activity.this, Payment_Activity.class);
                                        startActivity(pay);
                                        finish();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // do nothing
                                        Intent pay = new Intent(Payment_Activity.this, HomeActivity.class);
                                        startActivity(pay);
                                        finish();
                                    }
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                        Toast.makeText(this, "Payment failed: " + errorCode + " \n" + errorMessage, Toast.LENGTH_SHORT).show();
                        card_text.setText("Card");
                    }

                    break;

                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * optional mechanism to prepare a device for card transactions
     */
    private void doPrepareDeviceEzeTap() {
        EzeAPI.prepareDevice(this, REQUEST_CODE_PREPARE);
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    private void
    openPaymentPayloadPopup(final int REQUEST_CODE) {
        try {

            try {
                JSONObject jsonRequest = new JSONObject();
                JSONObject jsonOptionalParams = new JSONObject();
                JSONObject jsonReferences = new JSONObject();
                JSONObject jsonCustomer = new JSONObject();
                // Building Customer Object
                jsonCustomer.put("name","Name");
                jsonCustomer.put("mobileNo", "9876543210");
                jsonCustomer.put("email","test@testmail.com");
                JSONArray array = new JSONArray();
                // Building References Object
                JSONObject addlData = new JSONObject();
                //  String inv[]=inv_number.split(",");

                //   int count=inv.length;
                Calendar c = Calendar.getInstance();
                System.out.println("Current time => "+c.getTime());

                SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
                String formattedDate = df.format(c.getTime());
                Random random = new Random();
                int value = random.nextInt(10000);

                jsonReferences.put("reference1",formattedDate+"-"+value );
//                for(int i=1;i < count;i++)
//                {
//                    int r=i;
//                    r++;
//
//                    jsonReferences.put("reference"+r, inv[i]);
//
//                    array.put(inv[i]);
//                    array.put(inv[i]);
//                    addlData.put("feename", "");
//                }
                // Passing Additional References
                jsonOptionalParams.put("addlData", addlData);

                jsonReferences.put("additionalReferences", array);

                // Building Optional params Object
                jsonOptionalParams.put("amountCashback", " " + "");// Cannot
                // have
                // amount cashback in SALE transaction.
                jsonOptionalParams.put("amountTip", 0.00);
                jsonOptionalParams.put("references", jsonReferences);
                jsonOptionalParams.put("customer", jsonCustomer);

                // Pay to Account
                jsonOptionalParams.put("payToAccount", "258870782907");
                Date currentTime = Calendar.getInstance().getTime();


                JSONObject appData = new JSONObject();
                appData.put("app1", "app1"+currentTime);
                appData.put("app2", "app2"+currentTime);
                appData.put("app3", "app3"+currentTime);
                jsonOptionalParams.put("appData", appData);

                // Building final request object
                jsonRequest.put("amount","122");
                jsonRequest.put("options", jsonOptionalParams);

                InputMethodManager imm = (InputMethodManager) Payment_Activity.this
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                //imm.hideSoftInputFromWindow(payToAccount.getWindowToken(), 0);

                switch (REQUEST_CODE) {
                    case REQUEST_CODE_WALLET_TXN:
                        doWalletTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_CHEQUE_TXN:
                        // Building Cheque Object
                        JSONObject jsonCheque = new JSONObject();
                        jsonCheque.put("chequeNumber", "125441");
                        jsonCheque.put("bankCode", "TEST0001233");
                        jsonCheque.put("bankName", "TEST Bank");
                        jsonCheque.put("bankAccountNo", "1234567890");
                        jsonCheque.put("chequeDate", "2017-12-10");

                        jsonRequest.put("cheque", jsonCheque);

                        doChequeTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_SALE_TXN:
                        jsonRequest.put("mode", "SALE");//Card payment Mode
                        doSaleTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_CASH_BACK_TXN:
                        jsonRequest.put("mode", "CASHBACK");//Card payment Mode
                        // doCashbackTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_CASH_AT_POS_TXN:
                        jsonRequest.put("mode", "CASH@POS");//Card payment Mode
                        //   doCashAtPosTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_CASH_TXN:
                        //   doCashTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_PAY:
                        //  doPay(jsonRequest);
                        break;
                    case REQUEST_CODE_UPI:
                        //  doUPITxn(jsonRequest);
                        break;
                    case REQUEST_CODE_REMOTE_PAY:
                        //   doRemotePayTxn(jsonRequest);
                        break;
                    case REQUEST_CODE_QR_CODE_PAY:
                        //  doQrCodePayTxn(jsonRequest);
                        break;
                }
                //	alertDialog.cancel();
            } catch (Exception e) {
                e.printStackTrace();
            }


            //alertDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void doWalletTxn(JSONObject jsonRequest) {
        /*******************************************
         {
         "amount": "123",
         "options": {
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         }
         }
         *******************************************/
        EzeAPI.walletTransaction(Payment_Activity.this, REQUEST_CODE_WALLET_TXN, jsonRequest);
    }

    private void doChequeTxn(JSONObject jsonRequest) {
        /*****************************************
         {
         "amount": "123",
         "options": {
         "references": {
         "reference1": "1234",
         "additionalReferences": [
         "addRef_xx1",
         "addRef_xx2"
         ]
         },
         "customer": {
         "name": "xyz",
         "mobileNo": "1234567890",
         "email": "abc@xyz.com"
         }
         },
         "cheque": {
         "chequeNumber": "1234",
         "bankCode": "1234",
         "bankName": "xyz",
         "bankAccountNo": "1234",
         "chequeDate": "YYYY-MM-DD"
         }
         }
         *****************************************/
        EzeAPI.chequeTransaction(this, REQUEST_CODE_CHEQUE_TXN, jsonRequest);
    }



}