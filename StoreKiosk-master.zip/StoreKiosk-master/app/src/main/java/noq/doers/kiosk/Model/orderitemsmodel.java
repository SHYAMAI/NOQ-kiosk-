package noq.doers.kiosk.Model;

public class orderitemsmodel {

    public String getImage() {
        return  "http://noqapp.in/noq/store/"+image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public orderitemsmodel(String order_number, String item_name, String qty, String rate, String amount, String image) {
        this.order_number = order_number;
        this.item_name = item_name;
        this.qty = qty;
        this.rate = rate;
        this.amount = amount;
        this.image = image;

    }
    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    String order_number;
    String item_name;
    String qty;
    String rate;
    String amount;



    String image;

}
