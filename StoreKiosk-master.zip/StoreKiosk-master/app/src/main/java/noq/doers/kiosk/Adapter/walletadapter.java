package noq.doers.kiosk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import noq.doers.kiosk.Model.walletmodel;
import noq.doers.kiosk.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class walletadapter extends BaseAdapter {
    List<walletmodel> walletList;

    Context context;
    private static LayoutInflater inflater=null;
    public walletadapter(Context context, List<walletmodel> walletList) {
        // TODO Auto-generated constructor stub
        this.context = context;
        this.walletList = walletList;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return walletList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView creditdebit,description,createdate,closingbalance;
        ImageView os_img;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        walletadapter.Holder holder=new walletadapter.Holder();
        View rowView=convertView;

        if (rowView == null) {
            rowView = inflater.inflate(R.layout.wallet_item, null);



            holder.creditdebit =(TextView) rowView.findViewById(R.id.creditdebit);
            holder.description =(TextView) rowView.findViewById(R.id.description);
            holder.createdate =(TextView) rowView.findViewById(R.id.createdate);
            holder.closingbalance =(TextView) rowView.findViewById(R.id.closingbalance);
            holder.os_img = rowView.findViewById(R.id.prd_image);

            rowView.setTag(holder);
        } else {
            holder = (walletadapter.Holder) rowView.getTag();
        }


        //getting the hero of the specified position
        walletmodel wallet = walletList.get(position);

        if(Double.parseDouble(wallet.getCredit())>0){
            holder.creditdebit.setText(" + \u20B9 "+wallet.getCredit());
            holder.creditdebit.setTextColor(Color.parseColor("#00C853"));
        }
        else if(Double.parseDouble(wallet.getDebit())>0){
            holder.creditdebit.setText(" - \u20B9 "+wallet.getDebit());
            holder.creditdebit.setTextColor(Color.parseColor("#D32F2F"));
        }
if(wallet.getOrder_no().equals("0")){
    holder.description.setText(wallet.getDescription());

}else{
    holder.description.setText(wallet.getDescription() +" #"+wallet.getOrder_no());
}
        holder.createdate.setText(wallet.getCreate_date());
        holder.closingbalance.setText("\u20B9 "+wallet.getClosing_balance());
        Picasso.get()
                .load("https://dhakabankltd.com/wp-content/uploads/2013/12/short-term-deposit-services-img.png")
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into( holder.os_img);

        return rowView;
    }

}