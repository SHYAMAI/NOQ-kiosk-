package noq.doers.kiosk;
import android.app.Application;
import android.os.StrictMode;
import android.util.Log;

import com.orm.SugarContext;


public class Kioskclass extends Application {
    @Override
        public void onCreate() {
        super.onCreate();
        SugarContext.init(this);
    }
    @Override
    public void onTerminate(){
        super.onTerminate();
        SugarContext.terminate();
    }

}


