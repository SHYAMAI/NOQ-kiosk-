package noq.doers.kiosk.Model;

public class ModelCart {
    String product_id;
    String name;
    String tax;
    String totmrp;
    String mrp;
    String quantity;
    String price;
    String totprice;
    String offerid;
    String offername;
    String image;

    public ModelCart(String product_id, String name, String tax, String totmrp, String mrp, String quantity, String price, String totprice, String offerid, String offername, String image) {
        this.product_id = product_id;
        this.name = name;
        this.tax = tax;
        this.totmrp = totmrp;
        this.mrp = mrp;
        this.quantity = quantity;
        this.price = price;
        this.totprice = totprice;
        this.offerid = offerid;
        this.offername = offername;
        this.image = image;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    public String getTotmrp() {
        return totmrp;
    }

    public void setTotmrp(String totmrp) {
        this.totmrp = totmrp;
    }

    public String getMrp() {
        return mrp;
    }

    public void setMrp(String mrp) {
        this.mrp = mrp;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTotprice() {
        return totprice;
    }

    public void setTotprice(String totprice) {
        this.totprice = totprice;
    }

    public String getOfferid() {
        return offerid;
    }

    public void setOfferid(String offerid) {
        this.offerid = offerid;
    }

    public String getOffername() {
        return offername;
    }

    public void setOffername(String offername) {
        this.offername = offername;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}
