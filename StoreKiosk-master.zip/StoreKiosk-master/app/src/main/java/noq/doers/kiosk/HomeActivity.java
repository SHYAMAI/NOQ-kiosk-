package noq.doers.kiosk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import noq.doers.kiosk.Adapter.cartadapter;
import noq.doers.kiosk.DBModel.DB_CART;
import noq.doers.kiosk.DBModel.DB_USER;
import noq.doers.kiosk.Model.cartmodel;
import noq.doers.kiosk.Model.rfidlist;
import noq.doers.kiosk.utils.DBHelper;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.uxcam.UXCam;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;


public class HomeActivity extends AppCompatActivity {

    private Context context = null;

    //a List of type hero for holding list items
    List<cartmodel> heroList;
    List<rfidlist> rflist;

    //the listview
    GridView gridView;
    private EditText input_product;
  private ProgressDialog  dialog1 ;
  private TextView  prd_totitm,prd_amt,prd_tax,prd_totamt,welcome,prd_mrpamt,prd_saved;
private ImageView clearcart;
private ImageView scanbtn;
private String CARTLIST;
    LayoutInflater layoutInflater=null;
    private String CARD_ID;
    private String WALLET_AMT;
    private String USER_NAME;
    private String USER_MOBILE;
    private String USER_MAIL;
    private String USER_PIN,USERID;
    private String SavedAmt;
    private String STORE_ID;
    private TextView gohome,usrnam,waltamt;
    private Button ResetPin,WAllethistbtn,orderHistorybtn;
    private AlertDialog.Builder invalidpinbuilder;
private Boolean showalert ;
private Boolean isworking;
private TableRow savingrw;
private DBHelper mydb;
    FirebaseFirestore Fbdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //initializing objects
        isworking=false;
        heroList = new ArrayList<>();
        Fbdb = FirebaseFirestore.getInstance();
        gridView =  findViewById(R.id.list_of_f);
        input_product = findViewById(R.id.input_product);
        prd_totitm = findViewById(R.id.prd_totitm);
        prd_mrpamt = findViewById(R.id.prd_mrpamt);
        prd_saved = findViewById(R.id.prd_saved);
        clearcart = findViewById(R.id.clearcart);
        prd_amt = findViewById(R.id.prd_amt);
        prd_tax = findViewById(R.id.prd_tax);
        gohome = findViewById(R.id.gohome);
        prd_totamt   = findViewById(R.id.prd_totamt);
        welcome   = findViewById(R.id.welcome);
        waltamt   = findViewById(R.id.walamt);
        savingrw   = findViewById(R.id.savingrw);
        usrnam   = findViewById(R.id.usrnam);
        scanbtn   = findViewById(R.id.scanbtn);
        ResetPin   = findViewById(R.id.resetpin);
        WAllethistbtn   = findViewById(R.id.wallethistory);
        orderHistorybtn   = findViewById(R.id.transachistory);
        welcome.setVisibility(View.VISIBLE);
        savingrw.setVisibility(View.INVISIBLE);
        gridView.setVisibility(View.GONE);
        // Check if no view has focus:
        showalert=true;

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
//        List<DB_USER> user = DB_USER.find(DB_USER.class, "dummy = ?", "user");
        mydb=new DBHelper(HomeActivity.this);
        DB_USER user = new DB_USER();
        user = mydb.getAllUsers();
        if(user.getMail()==null){

        }else{
            CARD_ID= user.getCard();
            WALLET_AMT= user.getWalletbalance();
            USER_NAME= user.getName();
            USER_MOBILE= user.getMobile();
            USER_MAIL= user.getMail();
            USER_PIN= user.getPin();
            USERID= String.valueOf(user.getUid());
            STORE_ID= String.valueOf(user.getStore_id());
        }
        if(USERID==null||USERID.contains("null")||USERID.contains("NULL")){
            AlertDialog.Builder invaliduser = new AlertDialog.Builder(HomeActivity.this);
            invaliduser.setMessage("Sorry There is Problem in Getting Customer Details,\n Please Try again")
                    .setTitle("Alert")
                    .setCancelable(false)
                    .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent setIntent = new Intent(HomeActivity.this, SmartActivity.class);
                            setIntent.addCategory(Intent.CATEGORY_HOME);
                            setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(setIntent);
                            finish();
                        }
                    });
            //Creating dialog box
            AlertDialog alert = invaliduser.create();
            //Setting the title manually
            alert.show();
        }else{
            waltamt.setText("\u20B9 "+WALLET_AMT);
            usrnam.setText("Welcome "+USER_NAME);
            welcome.setText("Welcome "+USER_NAME+"\n To NoQ Store - Sreevatsa Residency \n Start Shopping By Showing Product on Barcode");
        }
        input_product.setEnabled(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if ( input_product!= null) {
                    Log.d("FOC","Set Focus");
                    input_product.clearFocus();
                    input_product.setFocusableInTouchMode(true);
                    input_product.requestFocus();
                }
            }
        }, 0);
        input_product.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent keyevent) {
                //If the keyevent is a key-down event on the "enter" button
                if ((keyevent.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    if (!isworking) {
                        isworking=true;
//                        getitems(input_product.getText().toString());
                        getitems(input_product.getText().toString()) ;
                    }
                }
                return false;
            }
        });
        input_product.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                // Check if no view has focus:
                if (v != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        });
        ResetPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder invalid = new AlertDialog.Builder(HomeActivity.this);
                invalid.setMessage("Are You Sure to Reset Your Pin.\n Note: New Pin Will be Sent To Your Registered mobile Number")
                        .setTitle("Alert")
                        .setCancelable(false)
                        .setPositiveButton("RESET", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                resetpin(CARD_ID);
                                dialog.dismiss();
                            }
                        }
                        ).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                //Creating dialog box
                AlertDialog alert = invalid.create();
                //Setting the title manually
                alert.show();
            }
        });
        WAllethistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Gson gson = new Gson();
                String json = gson.toJson(heroList);
                Log.d("JSS",json);  Intent setIntent = new Intent(HomeActivity.this, WalletActivity.class);
                setIntent.putExtra("cartjson",json);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                startActivity(setIntent);
                finish();
            }
        });
       orderHistorybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Gson gson = new Gson();
                String json = gson.toJson(heroList);
                Log.d("JSS",json);  Intent setIntent = new Intent(HomeActivity.this, orderActivity.class);
                setIntent.putExtra("cartjson",json);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                startActivity(setIntent);
                finish();
            }
        });
    gohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> articleParams = new HashMap<String, String>();
                articleParams.put("FROM","MY_CART");
                articleParams.put("ACTION","HOME_BUTTON_CLICKED");
                UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simpleDateFormat.format(new Date());
                Log.d("MainActivity", "Current Timestamp: " + format);
                log_Event log_Events = new log_Event();
                Gson gson = new Gson();
                String json = gson.toJson(articleParams);
                HashMap<String , String> param = new HashMap<>();
                param.put("APP_ID","KIOSK");
                param.put("USER_ID",USERID);
                param.put("EVENT_NAME","CANCEL_TRANSACTION");
                param.put("EVENT_JSON",json);
                param.put("EVENT_TIME",format);
                log_Events.execute(param);
                Intent setIntent = new Intent(HomeActivity.this, SmartActivity.class);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        scanbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Iterator itr = DB_USER.findAll(DB_USER.class);
//                while(itr.hasNext()){
//                    Object element = itr.next();
//                    Log.e("OPT",element.toString());
//                }
                // custom dialog
          if(heroList.size()>0){
             String ord_id = String.valueOf(nDigitRandomNo(5))+USERID;
              Gson gson = new Gson();
              String json = gson.toJson(heroList);
              Log.d("JSS",json);
              Intent setIntent = new Intent(HomeActivity.this, AccessActivity.class);
              setIntent.putExtra("cartjson",json);
              setIntent.putExtra("payamnt",prd_totamt.getText().toString());
              setIntent.putExtra("taxtotal",prd_tax.getText().toString());
              setIntent.putExtra("amtonly",prd_amt.getText().toString());
              setIntent.putExtra("ordid",ord_id);
              setIntent.putExtra("savedamt",SavedAmt);
              setIntent.addCategory(Intent.CATEGORY_HOME);
              setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
              startActivity(setIntent);
          }
            }
        });
        clearcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              try{
                  if (heroList.size()>0){
                  heroList.clear();
                  updatetotal();
              }}catch (Exception fds){
              }
            }
        });
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            CARTLIST= "";
        } else {
           try {
               CARTLIST= extras.getString("cartjson");
               JsonParser parser = new JsonParser();
               JsonArray paymentsArray = parser.parse(CARTLIST).getAsJsonArray();
               for(int i = 0; i < paymentsArray.size(); i++) {
                   JsonObject jsonobject = paymentsArray.get(i).getAsJsonObject();
                   String image = jsonobject.get("image").getAsString();
                   String product_id = jsonobject.get("product_id").getAsString();
                   String barcode = jsonobject.get("barcode").getAsString();
                   String name = jsonobject.get("name").getAsString();
                   String combo_id = jsonobject.get("combo_id").getAsString();
                   Double price = jsonobject.get("price").getAsDouble();
                   Double selling_price = jsonobject.get("selling_price").getAsDouble();
                   Double mrpqty = jsonobject.get("mrpqty").getAsDouble();
                   Double priceqty = jsonobject.get("priceqty").getAsDouble();
                   Double taxper = jsonobject.get("taxper").getAsDouble();
                   String qty = jsonobject.get("QTY").getAsString();
                   String rbar = jsonobject.get("rfbar").getAsString();
                   String rf = jsonobject.get("rf").getAsString();
                   String offerid=jsonobject.get("offerid").getAsString();
                   String offername=jsonobject.get("offername").getAsString();
                   JsonParser parser2 = new JsonParser();
                   JsonArray paymentsArray2 = parser2.parse(String.valueOf(jsonobject.get("rflis").getAsJsonArray())).getAsJsonArray();
                   rflist = new ArrayList<>();
                   for(int j = 0; j < paymentsArray.size(); j++) {
                       JsonObject jsonobject2 = paymentsArray2.get(j).getAsJsonObject();
                       rflist.add(new rfidlist(jsonobject2.get("rfid_barcode").getAsString(),jsonobject2.get("rfid").getAsString()));
                   }
                   addtocart(image, product_id, barcode, name, combo_id, getdecimalformat(price), getdecimalformat(selling_price),
                           getdecimalformat(mrpqty), getdecimalformat(priceqty), getdecimalformat(taxper),qty,rflist,rbar,rf,offerid,offername);
               }
           }catch (Exception dfs){
Log.e("ERR",dfs.getMessage());
           }
        }
    }
    private int nDigitRandomNo(int digits){
        int max = (int) Math.pow(10,(digits)) - 1; //for digits =7, max will be 9999999
        int min = (int) Math.pow(10, digits-1); //for digits = 7, min will be 1000000
        int range = max-min; //This is 8999999
        Random r = new Random();
        int x = r.nextInt(range);// This will generate random integers in range 0 - 8999999
        int nDigitRandomNo = x+min; //Our random rumber will be any random number x + min
        return nDigitRandomNo;
    }
//public void getfireitems(String barcode){
//    DocumentReference product = Fbdb.collection("products").document(barcode);
//    product.get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot> () {
//        @Override
//        public void onComplete(@NonNull Task < DocumentSnapshot > task) {
//            if (task.isSuccessful()) {
//                DocumentSnapshot doc = task.getResult();
//               StringBuilder fields = new StringBuilder("");
//                fields.append("Name: ").append(doc.get("name"));
//                fields.append("\nId: ").append(doc.get("id"));
//                fields.append("\nPrice: ").append(doc.get("price"));
//                Toast.makeText(HomeActivity.this, fields.toString(), Toast.LENGTH_SHORT).show();
//            }
//        }
//    })
//            .addOnFailureListener(new OnFailureListener() {
//                @Override
//                public void onFailure(@NonNull Exception e) {
//                }
//            });
//}
    private void getitems(String barcode){
       isworking=true;
       input_product.setEnabled(false);
       input_product.setText("");
      dialog1 = ProgressDialog.show(HomeActivity.this, "Please Wait", "Please Wait...");
       dialog1.setCancelable(true);
       HashMap<String , String> param = new HashMap<>();
       param.put("barcode",barcode);
       param.put("customerid",USERID);
       param.put("storeid",STORE_ID);
       // String o=globalValue.getString("barcode");
       System.out.println("Params:"+param);
       AndroidNetworking.post("http://noqapp.in/noq/prod/api/get_items/")
               .addBodyParameter(param)
               .setPriority(Priority.MEDIUM)
               .build()
               .getAsJSONObject(new JSONObjectRequestListener() {
                   @Override
                   public void onResponse(JSONObject response) {
                       isworking=false;
                       Log.e("IN","JSON :"+response.toString());
                       try {
                           if (response.getString("status").equalsIgnoreCase("true")){
                               JSONObject jsonobject = response.getJSONObject("data");
                               Log.e("IN","JSON Val:"+jsonobject.getString("price"));
                               //String image, String product_id, String barcode, String name, String combo_id, int price, int selling_price, int mrpqty, int priceqty, int taxper
                               String image = jsonobject.getString("image");
                               String product_id = jsonobject.getString("product_id");
                               String barcode = jsonobject.getString("barcode");
                               String name = jsonobject.getString("name");
                               String combo_id = jsonobject.getString("combo_id");
                               Double price = jsonobject.getDouble("price");
                               Double selling_price = jsonobject.getDouble("selling_price");
                               Double mrpqty = jsonobject.getDouble("mrpqty");
                               Double priceqty = jsonobject.getDouble("priceqty");
                               Double taxper = jsonobject.getDouble("taxper");
                               String qty = "1";
                               String rbar = jsonobject.getString("rfid_barcode");
                               String rf =  jsonobject.getString("rfid");
                               rflist = new ArrayList<>();
                               rflist.add(new rfidlist(rbar,rf));
                               String offerid=jsonobject.getString("offerid");
                               String offername=jsonobject.getString("offername");
                               addtocart(image, product_id, barcode, name, combo_id, getdecimalformat(price),
                                       getdecimalformat(selling_price), getdecimalformat(mrpqty), getdecimalformat(priceqty),
                                       getdecimalformat(taxper),qty,rflist,rbar,rf,offerid,offername);
                           }else {
                              AlertDialog.Builder invalid = new AlertDialog.Builder(HomeActivity.this);
                               invalid.setMessage("No Item Found . Scan Another Item")
                                       .setTitle("Alert")
                                       .setCancelable(false)
                                       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                           public void onClick(DialogInterface dialog, int id) {
                                                dialog.dismiss();
                                           }
                                       });
                               //Creating dialog box
                               AlertDialog alert = invalid.create();
                               //Setting the title manually
                               alert.setTitle("Alert");
                               alert.show();
                           }
                       } catch (JSONException e) {
                           e.printStackTrace();
                       }
                       dialog1.dismiss();
                       new Handler().postDelayed(new Runnable() {
                           @Override
                           public void run() {
                               if ( input_product!= null) {
                                   Log.d("FOC","Set Focus");
                                   input_product.setEnabled(true);
                                   input_product.clearFocus();
                                   input_product.setFocusableInTouchMode(true);
                                   input_product.requestFocus();
                                   isworking=false;
                               }
                           }
                       }, 1000);
                   }
                   @Override
                   public void onError(ANError anError) {
                       isworking=false;
                       dialog1.dismiss();
                       Log.e("IN","Error :"+anError.getErrorCode());
                       Log.e("IN","Error :"+anError.getErrorBody());
                       Log.e("IN","Error :"+anError.getErrorDetail());
                       AlertDialog.Builder invalid = new AlertDialog.Builder(HomeActivity.this);
                       invalid.setMessage("No Item Found . Scan Another Item")
                               .setTitle("Alert")
                               .setCancelable(false)
                               .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                   public void onClick(DialogInterface dialog, int id) {
                                       dialog.dismiss();
                                   }
                               });
                       //Creating dialog box
                       AlertDialog alert = invalidpinbuilder.create();
                       //Setting the title manually
                       alert.setTitle("Alert");
                       alert.show();
                       new Handler().postDelayed(new Runnable() {
                           @Override
                           public void run() {
                               if ( input_product!= null) {
                                   input_product.setEnabled(true);
                                   Log.d("FOC","Set Focus");
                                   input_product.clearFocus();
                                   input_product.setFocusableInTouchMode(true);
                                   input_product.requestFocus();
                               }
                           }
                       }, 1000);   
                   }
               });
   }
    private void resetpin(String cardid){
        input_product.setText("");
        dialog1 = ProgressDialog.show(HomeActivity.this, "Please Wait", "Please Wait...");
        dialog1.setCancelable(true);
        HashMap<String , String> param = new HashMap<>();
        param.put("cardid",cardid);
        param.put("storeid",STORE_ID);
        // String o=globalValue.getString("barcode");
        System.out.println("Params:"+param);
        AndroidNetworking.post("http://noqapp.in/noq/prod/api/reset_pin_kiosk/")
                .addBodyParameter(param)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("IN","JSON :"+response.toString());
                        try {
                            if (response.getString("status").equalsIgnoreCase("true")){
                                Map<String, String> articleParams = new HashMap<String, String>();
                                articleParams.put("CARD_ID", CARD_ID);
                                UXCam.logEvent("RESET_PIN", articleParams);
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String format = simpleDateFormat.format(new Date());
                                Log.d("MainActivity", "Current Timestamp: " + format);
                                log_Event log_Events = new log_Event();
                                Gson gson = new Gson();
                                String json = gson.toJson(articleParams);
                                HashMap<String , String> param = new HashMap<>();
                                param.put("APP_ID","KIOSK");
                                param.put("USER_ID",USERID);
                                param.put("EVENT_NAME","RESET_PIN");
                                param.put("EVENT_JSON",json);
                                param.put("EVENT_TIME",format);
                                log_Events.execute(param);
                                JSONObject responset = new JSONObject(response.getString("data"));
                                String codepin = responset.getString("codepin");
                                USER_PIN= codepin;
                                mydb.updateUser(Integer.parseInt(USERID),USER_PIN);
                               // List<DB_USER> user = DB_USER.find(DB_USER.class, "dummy = ?", "user");
                             //   user.get(0).setPin(codepin);
                              //  user.get(0).save();
                                invalidpinbuilder = new AlertDialog.Builder(HomeActivity.this);
                                invalidpinbuilder.setMessage("Pin Changed Successfully")
                                        .setTitle("Alert")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.dismiss();
                                            }
                                        });
                                //Creating dialog box
                                AlertDialog alert = invalidpinbuilder.create();
                                //Setting the title manually
                                alert.setTitle("Alert");
                                alert.show();
                                Log.e("IN","PIN :"+codepin.toString());
                            }else {
                                invalidpinbuilder = new AlertDialog.Builder(HomeActivity.this);
                                invalidpinbuilder.setMessage("Pin Change Failed Try Again")
                                        .setTitle("Alert")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                    dialog.dismiss();
                                            }
                                        });
                                //Creating dialog box
                                AlertDialog alert = invalidpinbuilder.create();
                                //Setting the title manually
                                alert.setTitle("Alert");
                                alert.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        dialog1.dismiss();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if ( input_product!= null) {
                                    input_product.clearFocus();
                                    Log.d("FOC","Set Focus");
                                    input_product.setFocusableInTouchMode(true);
                                    input_product.requestFocus();
                                }
                            }
                        }, 1000);
                    }
                    @Override
                    public void onError(ANError anError) {
                        dialog1.dismiss();
                        Log.e("IN","Error :"+anError.getErrorCode());
                        Log.e("IN","Error :"+anError.getErrorBody());
                        Log.e("IN","Error :"+anError.getErrorDetail());
                        invalidpinbuilder = new AlertDialog.Builder(HomeActivity.this);
                        invalidpinbuilder.setMessage("Pin Change Failed Try Again")
                                .setTitle("Alert")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                    }
                                });
                        //Creating dialog box
                        AlertDialog alert = invalidpinbuilder.create();
                        //Setting the title manually
                        alert.setTitle("Alert");
                        alert.show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if ( input_product!= null) {
                                    input_product.clearFocus();
                                    Log.d("FOC","Set Focus");
                                    input_product.setFocusableInTouchMode(true);
                                    input_product.requestFocus();
                                }
                            }
                        }, 1000);
                    }
                });
    }
   private void addtocart(String image, String product_id, String barcode, String name, String combo_id, String price,
                          String selling_price, String mrpqty, String priceqty, String taxper, String QTY,
                          List<rfidlist> rflis,String rfbar,String rf,String offerid,String offername){
//       rflist = new ArrayList<>();
//       rflist.add(new rfidlist(rfbar,rf));
       Map<String, String> articleParams = new HashMap<String, String>();
       articleParams.put("ITEM_NAME", name);
       articleParams.put("PRICE", price);
       articleParams.put("QUANTITY", QTY);
       articleParams.put("ITEM_ID", product_id);
       articleParams.put("OFFER_ID",offerid);
       articleParams.put("OFFER_NAME",offername);
       UXCam.logEvent("Add To Cart", articleParams);
       SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
       String format = simpleDateFormat.format(new Date());
       Log.d("MainActivity", "Current Timestamp: " + format);
       log_Event log_Events = new log_Event();
       Gson gson = new Gson();
       String json = gson.toJson(articleParams);
       HashMap<String , String> param = new HashMap<>();
       param.put("APP_ID","KIOSK");
       param.put("USER_ID",USERID);
       param.put("EVENT_NAME","ADD_TO_CART");
       param.put("EVENT_JSON",json);
       param.put("EVENT_TIME",format);
       log_Events.execute(param);
        boolean isnew = true;
       if(heroList.size()==0){
           heroList.add(new cartmodel(image, product_id, barcode, name, combo_id, price, selling_price, mrpqty, priceqty, taxper,  QTY,rflist,rf,rfbar,offerid,offername));
           cartadapter adapter = new cartadapter(HomeActivity.this, heroList);
           gridView.setAdapter(adapter);
           isnew = false;
       }else{
           for(int i = 0; i < heroList.size(); i++)
           {
               if(Double.parseDouble(heroList.get(i).getProduct_id()) == Double.parseDouble(product_id)){
                   heroList.get(i).setQTY(String.valueOf(Integer.parseInt(heroList.get(i).getQTY())+Integer.parseInt(QTY)));
                   isnew = false;
               }
           }
       }
       if(isnew)
       {
           heroList.add(new cartmodel(image, product_id, barcode, name, combo_id, price, selling_price, mrpqty, priceqty, taxper,  QTY,rflist,rf,rfbar,offerid,offername));
           cartadapter adapter = new cartadapter(HomeActivity.this, heroList);
           gridView.setAdapter(adapter);
       }
       updatetotal();
       gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               TextView prd_name =(TextView) view.findViewById(R.id.prd_name);
                final int pos=position;
               AlertDialog.Builder Alertremove = new AlertDialog.Builder(HomeActivity.this);
               Alertremove.setMessage("Are You Sure to Remove "+prd_name.getText().toString()+" from cart")
                       .setTitle("Remove Alert")
                       .setCancelable(true)
                       .setPositiveButton("Yes Remove", new DialogInterface.OnClickListener() {
                           public void onClick(DialogInterface dialog, int id) {
                               dialog.dismiss();
                               Map<String, String> articleParams = new HashMap<String, String>();
                               articleParams.put("ITEM_NAME", heroList.get(pos).getName());
                               articleParams.put("PRICE", heroList.get(pos).getPrice());
                               articleParams.put("QUANTITY", heroList.get(pos).getQTY());
                               articleParams.put("ITEM_ID", heroList.get(pos).getProduct_id());
                               UXCam.logEvent("REMOVE_CART", articleParams);
                               SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                               String format = simpleDateFormat.format(new Date());
                               Log.d("MainActivity", "Current Timestamp: " + format);
                               log_Event log_Events = new log_Event();
                               Gson gson = new Gson();
                               String json = gson.toJson(articleParams);
                               HashMap<String , String> param = new HashMap<>();
                               param.put("APP_ID","KIOSK");
                               param.put("USER_ID",USERID);
                               param.put("EVENT_NAME","REMOVE_CART");
                               param.put("EVENT_JSON",json);
                               param.put("EVENT_TIME",format);
                               log_Events.execute(param);
                               heroList.remove(pos);
                               updatetotal();
                           }
                       }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       dialog.dismiss();
                   }
               });
               //Creating dialog box
               AlertDialog alert = Alertremove.create();
               //Setting the title manually
               alert.show();
           }
       });
    }
    private void updatetotal() {
        Double totalamt=0.00;
        Double totalitems=0.00;
        Double amount=0.00;
        Double tax=0.00;
        if(heroList.size()>0){
            welcome.setVisibility(View.GONE);
            gridView.setVisibility(View.VISIBLE);
        }else{
            welcome.setVisibility(View.VISIBLE);
            gridView.setVisibility(View.GONE);
        }
        for(int i = 0; i < heroList.size(); i++) {
            // Here your room is available
            totalitems=totalitems + Double.parseDouble(heroList.get(i).getQTY());
            // tax =tax+Double.parseDouble(room.getTaxper());
            //   totalamt =totalamt + Double.parseDouble(room.getSelling_price());
            Double mrpqty = Double.parseDouble(heroList.get(i).getQTY()) * Double.parseDouble(heroList.get(i).getSelling_price());
            Double totmrpqty = Double.parseDouble(heroList.get(i).getQTY()) * Double.parseDouble(heroList.get(i).getPrice());
            heroList.get(i).setMrpqty(getdecimalformat(mrpqty));
            Double x = Double.parseDouble(heroList.get(i).getMrpqty()) / (100 + Double.parseDouble(heroList.get(i).getTaxper()));
            tax = tax + x*Double.parseDouble(heroList.get(i).getTaxper());
            totalamt =totalamt + Double.parseDouble(heroList.get(i).getMrpqty());
            amount = amount +totmrpqty;
        }
        Double saved = amount-totalamt;
        if(saved>0){
            savingrw.setVisibility(View.VISIBLE);
        }else{
            savingrw.setVisibility(View.INVISIBLE);
        }
        SavedAmt=getdecimalformat(saved);
        prd_totitm.setText(String.valueOf(Math.round(totalitems)));
        prd_amt.setText(getdecimalformat(totalamt-tax));
        prd_saved.setText(getdecimalformat(saved));
        prd_mrpamt.setText(getdecimalformat(amount));
        prd_mrpamt.setPaintFlags(prd_mrpamt.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        prd_tax.setText(getdecimalformat(tax));
        prd_totamt.setText(getdecimalformat(totalamt));
        ((BaseAdapter) gridView.getAdapter()).notifyDataSetChanged();
        if(Double.parseDouble(WALLET_AMT)<=totalamt){
            if(showalert){
    AlertDialog.Builder Alertremove = new AlertDialog.Builder(HomeActivity.this);
    Alertremove.setMessage("Low Balance in Wallet (\u20B9"+WALLET_AMT+" )\n You Will Have to Pay Using Credit/Debit Card")
            .setTitle("Alert !")
            .setCancelable(true)
            .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
    //Creating dialog box
    AlertDialog alert = Alertremove.create();
    //Setting the title manually
    alert.show();
            }
    showalert=false;
            isworking=false;
        }
    }
    private String getdecimalformat(Double val){
       int decimals = 2;
       BigDecimal value = new BigDecimal(val).setScale(decimals, RoundingMode.HALF_EVEN);
      return String.valueOf(value);
   }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        isworking=false;
        Map<String, String> articleParams = new HashMap<String, String>();
        articleParams.put("FROM","MY_CART");
        articleParams.put("ACTION","BACK_PRESSED");
        UXCam.logEvent("CANCEL_TRANSACTION", articleParams);
        log_Event log_Events = new log_Event();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simpleDateFormat.format(new Date());
        Log.d("MainActivity", "Current Timestamp: " + format);
        Gson gson = new Gson();
        String json = gson.toJson(articleParams);
        HashMap<String , String> param = new HashMap<>();
        param.put("APP_ID","KIOSK");
        param.put("USER_ID",USERID);
        param.put("EVENT_NAME","CANCEL_TRANSACTION");
        param.put("EVENT_JSON",json);
        param.put("EVENT_TIME",format);
        //noinspection unchecked
        log_Events.execute(param);
        Intent setIntent = new Intent(HomeActivity.this, SmartActivity.class);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(setIntent);
        finish();
    }

}
