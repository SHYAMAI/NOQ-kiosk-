package noq.doers.kiosk.Model;

import java.util.List;

public class ordata  {

    String product_id;
    String barcode;
    String quantity;
    String tax_per;
    String tax_amount;
    String amount;


    String offerid;
    String offername;
    List<rfidlist> rfid_list;



    public ordata(String product_id, String barcode, String quantity, String tax_per, String tax_amount,
                  String amount, List<rfidlist> rfid_list,String offerid,String offername) {

        this.product_id = product_id;
        this.barcode = barcode;
        this.quantity = quantity;
        this.tax_per = tax_per;
        this.tax_amount = tax_amount;
        this.amount = amount;
        this.rfid_list = rfid_list;
        this.offerid = offerid;
        this.offername = offername;
    }

    public String getOfferid() {
        return offerid;
    }

    public void setOfferid(String offerid) {
        this.offerid = offerid;
    }

    public String getOffername() {
        return offername;
    }

    public void setOffername(String offername) {
        this.offername = offername;
    }
    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public List<rfidlist> getRfid_list() {
        return rfid_list;
    }

    public void setRfid_list(List<rfidlist> rfid_list) {
        this.rfid_list = rfid_list;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTax_amount() {
        return tax_amount;
    }

    public void setTax_amount(String tax_amount) {
        this.tax_amount = tax_amount;
    }

    public String getTax_per() {
        return tax_per;
    }

    public void setTax_per(String tax_per) {
        this.tax_per = tax_per;
    }
    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }
}