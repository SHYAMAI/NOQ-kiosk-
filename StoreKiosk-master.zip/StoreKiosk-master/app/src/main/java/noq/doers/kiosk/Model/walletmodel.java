package noq.doers.kiosk.Model;

public class walletmodel {

    String closing_balance ,create_date,description,order_no,debit,credit;

    public walletmodel(String closing_balance , String create_date, String description, String order_no, String debit, String credit) {
        this.create_date = create_date;
        this.closing_balance = closing_balance;
        this.description = description;
        this.order_no = order_no;
        this.debit = debit;
        this.credit = credit;
    }

    public String getClosing_balance() {
        return closing_balance;
    }

    public void setClosing_balance(String closing_balance) {
        this.closing_balance = closing_balance;
    }

    public String getCreate_date() {
        return create_date;
    }

    public void setCreate_date(String create_date) {
        this.create_date = create_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }




}
