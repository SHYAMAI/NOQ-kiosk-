package noq.doers.kiosk.Model;

public class rfidlist {


    String rfid_barcode;

    String rfid;

    public rfidlist(String rfid_barcode, String rfid) {
        this.rfid_barcode = rfid_barcode;
        this.rfid = rfid;

    }

    public String getRfid() {
        return rfid;
    }

    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    public String getRfid_barcode() {
        return rfid_barcode;
    }

    public void setRfid_barcode(String rfid_barcode) {
        this.rfid_barcode = rfid_barcode;
    }
}


