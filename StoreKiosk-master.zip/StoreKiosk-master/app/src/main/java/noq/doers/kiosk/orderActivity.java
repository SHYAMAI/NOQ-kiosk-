package noq.doers.kiosk;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import noq.doers.kiosk.Adapter.orderadapter;
import noq.doers.kiosk.Adapter.orderitemsadapter;
import noq.doers.kiosk.DBModel.DB_USER;
import noq.doers.kiosk.Model.orderitemsmodel;
import noq.doers.kiosk.Model.ordermodel;
import noq.doers.kiosk.utils.DBHelper;

import com.yarolegovich.lovelydialog.LovelyCustomDialog;
import com.yarolegovich.lovelydialog.ViewConfigurator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class orderActivity extends AppCompatActivity {
    List<ordermodel> orderList;
    List<orderitemsmodel> orderitemsList;
    ProgressDialog dialog1;
    private ListView listView;
    private TextView totalpurch,gotocart;
    private String CARD_ID;
    private String WALLET_AMT;
    private String USER_NAME;
    private String USER_MOBILE;
    private String USER_MAIL;
    private String USER_PIN,STORE_ID;
    private String CARTLIST,USERID;
    private String TOTALPUR="0";
    private DBHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        listView = findViewById(R.id.list_of_f);
        totalpurch = findViewById(R.id.totalpurch);
        gotocart = findViewById(R.id.gohome);
        orderList = new ArrayList<>();
        orderitemsList = new ArrayList<>();
//        List<DB_USER> user = DB_USER.find(DB_USER.class, "dummy = ?", "user");
        mydb=new DBHelper(orderActivity.this);
        DB_USER user = new DB_USER();
        user = mydb.getAllUsers();
        if(user.getMail()==null){
        }else{
            CARD_ID= user.getCard();
            WALLET_AMT= user.getWalletbalance();
            USER_NAME= user.getName();
            USER_MOBILE= user.getMobile();
            USER_MAIL= user.getMail();
            USER_PIN= user.getPin();
            USERID= String.valueOf(user.getUid());
            STORE_ID= String.valueOf(user.getStore_id());
        }
        gethistory(CARD_ID);
        gotocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent setIntent = new Intent(orderActivity.this, HomeActivity.class);
                setIntent.putExtra("cartjson",CARTLIST);
                setIntent.addCategory(Intent.CATEGORY_HOME);
                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(setIntent);
                finish();
            }
        });
        Bundle extras = getIntent().getExtras();
        if(extras == null) {
            CARTLIST= "";
        } else {
            try{
                CARTLIST= extras.getString("cartjson");
            }catch (Exception dd){
            }
        }
    }
    private void gethistory(String userid){
        dialog1 = ProgressDialog.show(orderActivity.this, "Please Wait", "Please Wait...");
        HashMap<String , String> param = new HashMap<>();
        param.put("cardid",userid);
        param.put("store_id",STORE_ID);
        // String o=globalValue.getString("barcode");
//        System.out.println("Params:"+param);
        AndroidNetworking.post("http://noqapp.in/noq/prod/api/orders_list_kiosk/")
                .addBodyParameter(param)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        orderList.clear();
                     Log.i("JSN",response.toString());
                     try {
                         Double drt=0.00;
                            for (int i = 0; i < response.length(); i++) {
                                String  order_number,status,count,created_date,payment_type,id;
                                JSONObject walletobj = response.getJSONObject(i);
                                if(walletobj.has("order_number")){
                                    id = walletobj.getString("id");
                                    order_number = walletobj.getString("order_number");
                                    status        = walletobj.getString("grand_total");
                                    count   = walletobj.getString("count");
                                    created_date    = walletobj.getString("created_date");
                                    payment_type    = walletobj.getString("payment_type");
                                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                                    Date newDate = null;
                                    try {
                                        newDate = format.parse(created_date);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                    format = new SimpleDateFormat("MMM dd,yyyy");
                                    String date = format.format(newDate);
                                    drt += Double.parseDouble(status);
                                    orderList.add(new ordermodel( id,order_number,status,count,date,payment_type));
                                }
                            }
                            TOTALPUR = String.valueOf(drt);
                            totalpurch.setText("\u20B9 "+TOTALPUR);
                            orderadapter adapter = new orderadapter(orderActivity.this, orderList);
                            listView.setAdapter(adapter);
                            dialog1.dismiss();
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                             @Override
                             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                 TextView ord =view.findViewById(R.id.ordid);
                                 getorditms(ord.getText().toString());
                             }
                         });
                        }catch(Exception dfs){
                            dialog1.dismiss();
                        }
                    }
                    @Override
                    public void onError(ANError anError) {
                        Log.e("IN","Error :"+anError.getErrorCode());
                        Log.e("IN","Error :"+anError.getErrorBody());
                        dialog1.dismiss();
                        Log.e("IN","Error :"+anError.getErrorDetail());
                        Toast.makeText(orderActivity.this, "No Item Found. Scan Another Item", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void getorditms(final String ordid){
        final ProgressDialog dialog = ProgressDialog.show(orderActivity.this, "Please Wait", "Please Wait...");
        HashMap<String , String> param = new HashMap<>();
        param.put("order_id",ordid);
        // String o=globalValue.getString("barcode");
//        System.out.println("Params:"+param);
        AndroidNetworking.post("http://noqapp.in/noq/prod/api/orderitems_kiosk/")
                .addBodyParameter(param)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("JSN",response.toString());
                        try {
                            if (response.getString("status").equalsIgnoreCase("true")) {
                               final JSONArray responset = new JSONArray(response.getString("data"));
                                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(orderActivity.this);
                                LayoutInflater inflater = orderActivity.this.getLayoutInflater();
                                View dialogView = inflater.inflate(R.layout.list_ord, null);
                                dialogBuilder.setView(dialogView);
                                ListView Orderlistview = dialogView.findViewById(R.id.list_of_f);
                                TextView ordtitle = dialogView.findViewById(R.id.ordtitle);
                                TextView closedialog = dialogView.findViewById(R.id.closedialog);
                                ordtitle.setText(" # "+ordid);
                                    for (int i = 0; i < responset.length(); i++) {
                                        String order_number, item_name, qty, rate, amount,image;
                                        JSONObject walletobj = responset.getJSONObject(i);
                                        if (walletobj.has("order_id")) {
                                            item_name = walletobj.getString("item_name");
                                            order_number = walletobj.getString("order_id");
                                            qty = walletobj.getString("qty");
                                            rate = walletobj.getString("rate");
                                            amount = walletobj.getString("amount");
                                            image = walletobj.getString("image");
                                            orderitemsList.add(new orderitemsmodel(order_number, item_name, qty, rate, amount,image));
                                        }
                                    }
                                    orderitemsadapter adapter = new orderitemsadapter(orderActivity.this, orderitemsList);
                                    Orderlistview.setAdapter(adapter);
                                final AlertDialog alertDialog = dialogBuilder.create();
                                alertDialog.show();
                                closedialog.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        alertDialog.dismiss();
                                    }
                                });
                            }
                            dialog.dismiss();
                        }catch(Exception dfs){
                            dialog.dismiss();
                        }
                    }
                    @Override
                    public void onError(ANError anError) {
                        Log.e("IN","Error :"+anError.getErrorCode());
                        Log.e("IN","Error :"+anError.getErrorBody());
                        dialog.dismiss();
                        Log.e("IN","Error :"+anError.getErrorDetail());
                        Toast.makeText(orderActivity.this, "No Item Found . Scan Another Item", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
