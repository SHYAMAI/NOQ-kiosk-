package noq.doers.kiosk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.eze.api.EzeAPI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

public class EzeNativeSampleActivity extends Activity  {
	/**
	 * The response is sent back to your activity with a result code and request
	 * code based
	 */
	private final int REQUEST_CODE_INITIALIZE = 10001;
	private final int REQUEST_CODE_PREPARE = 10002;
	private final int REQUEST_CODE_WALLET_TXN = 10003;
	private final int REQUEST_CODE_CHEQUE_TXN = 10004;
	private final int REQUEST_CODE_SALE_TXN = 10006;
	private final int REQUEST_CODE_CASH_BACK_TXN = 10007;
	private final int REQUEST_CODE_CASH_AT_POS_TXN = 10008;
	private final int REQUEST_CODE_CASH_TXN = 10009;
	private final int REQUEST_CODE_SEARCH = 10010;
	private final int REQUEST_CODE_VOID = 10011;
	private final int REQUEST_CODE_ATTACH_SIGN = 10012;
	private final int REQUEST_CODE_UPDATE = 10013;
	private final int REQUEST_CODE_CLOSE = 10014;
	private final int REQUEST_CODE_GET_TXN_DETAIL = 10015;
	private final int REQUEST_CODE_GET_INCOMPLETE_TXN = 10016;

	/**
	 * The Base64 Image bitmap string for attach e-signature
	 */
	private ImageView img;
	/**
	 * unique ID for a transaction in EzeTap EMI Id associated with the
	 * transaction
	 */
	private String strTxnId = null, emiID = null;
	/**
	 * Error message
	 */
	private String mandatoryErrMsg = "Please fill up mandatory params.";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		doInitializeEzeTap();
		doPrepareDeviceEzeTap();
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {

				openPaymentPayloadPopup(REQUEST_CODE_SALE_TXN);

			}
		}, 1000);



	}


	/**
	 * invoke to initialize the SDK with the merchant key and the device (card
	 * reader) with bank keys
	 */
	private void doInitializeEzeTap() {
		/**********************************************
		 {
		 "demoAppKey": "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28",
		 "prodAppKey": "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28",
		 "merchantName": "DOERS_TECH_ENTERPRISE_SOL",
		 "userName": "7540042021",
		 "currencyCode": "INR",
		 "appMode": "DEMO",
		 "captureSignature": "false",
		 "prepareDevice": "false"
		 }
		 **********************************************/
		JSONObject jsonRequest = new JSONObject();
		try {
			jsonRequest.put("demoAppKey", "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28");
			jsonRequest.put("prodAppKey", "c6f2ee0c-ac91-4a79-90fb-b28cc6f89d28");
			jsonRequest.put("merchantName", "DOERS_TECH_ENTERPRISE_SOL");
			jsonRequest.put("userName", "7540042021");
			jsonRequest.put("currencyCode", "INR");
			jsonRequest.put("appMode", "DEMO");
			jsonRequest.put("captureSignature", "false");
			jsonRequest.put("prepareDevice", "false");
			EzeAPI.initialize(this, REQUEST_CODE_INITIALIZE, jsonRequest);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/**
	 * optional mechanism to prepare a device for card transactions
	 */
	private void doPrepareDeviceEzeTap() {
		EzeAPI.prepareDevice(this, REQUEST_CODE_PREPARE);
	}

	/**
	 * Ability to take wallet transaction for Mobiquick, Freecharge, Novopay
	 * etc.
	 */
	private void doWalletTxn(JSONObject jsonRequest) {
		/*******************************************
		 {
		 "amount": "123",
		 "options": {
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 }
		 }
		 *******************************************/
		EzeAPI.walletTransaction(EzeNativeSampleActivity.this, REQUEST_CODE_WALLET_TXN, jsonRequest);
	}

	/**
	 * Records cheque transaction
	 */
	private void doChequeTxn(JSONObject jsonRequest) {
		/*****************************************
		 {
		 "amount": "123",
		 "options": {
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 },
		 "cheque": {
		 "chequeNumber": "1234",
		 "bankCode": "1234",
		 "bankName": "xyz",
		 "bankAccountNo": "1234",
		 "chequeDate": "YYYY-MM-DD"
		 }
		 }
		 *****************************************/
		EzeAPI.chequeTransaction(this, REQUEST_CODE_CHEQUE_TXN, jsonRequest);
	}

	/**
	 * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
	 * transactions for Indian banks. Ability to perform EMI option.
	 */
	private void doSaleTxn(JSONObject jsonRequest) {
		/******************************************
		 {
		 "amount": "123",
		 "options": {
		 "amountCashback": 0,
		 "amountTip": 0,
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 },
		 "mode": "SALE"
		 }
		 ******************************************/
		EzeAPI.cardTransaction(this, REQUEST_CODE_SALE_TXN, jsonRequest);
	}

	/**
	 * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
	 * transactions for Indian banks. Ability to perform cashback option.
	 */
	private void doCashbackTxn(JSONObject jsonRequest) {
		/******************************************
		 {
		 "amount": "123",
		 "options": {
		 "amountCashback": 100,
		 "amountTip": 0,
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 },
		 "mode": "CASHBACK"
		 }
		 ******************************************/
		EzeAPI.cardTransaction(this, REQUEST_CODE_CASH_BACK_TXN, jsonRequest);
	}

	/**
	 * Take credit card transactions for Visa, Mastercard and Rupay. Debit card
	 * transactions for Indian banks. Ability to perform cash@pos option.
	 */
	private void doCashAtPosTxn(JSONObject jsonRequest) {
		/******************************************
		 {
		 "amount": "0",
		 "options": {
		 "amountCashback": 100,
		 "amountTip": 0,
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 },
		 "mode": "CASH@POS"
		 }
		 ******************************************/
		EzeAPI.cardTransaction(this, REQUEST_CODE_CASH_AT_POS_TXN, jsonRequest);
	}

	/**
	 * Ability to record cash transaction
	 */
	private void doCashTxn(JSONObject jsonRequest) {
		/******************************************
		 {
		 "amount": "123",
		 "options": {
		 "references": {
		 "reference1": "1234",
		 "additionalReferences": [
		 "addRef_xx1",
		 "addRef_xx2"
		 ]
		 },
		 "customer": {
		 "name": "xyz",
		 "mobileNo": "1234567890",
		 "email": "abc@xyz.com"
		 }
		 }
		 }
		 ******************************************/
		EzeAPI.cashTransaction(this, REQUEST_CODE_CASH_TXN, jsonRequest);
	}

	/**
	 * search transactions for a merchant based on certain search parameters
	 */
	private void doSearchTxn() {
		/*********************************
		 {
		 "agentName": "Demo User"
		 }
		 *********************************/
		JSONObject jsonRequest = new JSONObject();
		try {
			jsonRequest.put("agentName", "Enter your user name");
			EzeAPI.searchTransaction(this, REQUEST_CODE_SEARCH, jsonRequest);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Void transaction method is invoked to void a payment transaction
	 */
	private void doVoidTxn() {
		if (isTransactionIdValid()) {
			EzeAPI.voidTransaction(this, REQUEST_CODE_VOID, strTxnId);// pass your transaction id value here
		} else
			displayToast("Inorrect txn Id, please make a Txn.");

	}

	/**
	 * @param bitmap
	 * @return
	 */
	public String getEncoded64ImageStringFromBitmap(Bitmap bitmap) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
		byte[] byteFormat = stream.toByteArray();
		return Base64.encodeToString(byteFormat, Base64.NO_WRAP);
	}

	/**
	 * Use this operation to attach an e-signature from the customer for
	 * payments
	 */
	private void doAttachSignature() {
		/*******************************************
		 {
		 "tipAmount": 0,
		 "image": {
		 "imageData": "js9bsidvicbi3h",
		 "imageType": "JPEG",
		 "height": "",
		 "weight": ""
		 },
		 "txnId": "12355356345"
		 }
		 *******************************************/
		JSONObject jsonRequest = new JSONObject();
		JSONObject jsonImageObj = new JSONObject();
		try {
			img.buildDrawingCache();
			Bitmap bmap = img.getDrawingCache();
			String encodedImageData = getEncoded64ImageStringFromBitmap(bmap);
			// Building Image Object
			jsonImageObj.put("imageData", encodedImageData);
			jsonImageObj.put("imageType", "JPEG");
			jsonImageObj.put("height", "");// optional
			jsonImageObj.put("weight", "");// optional
			// Building final request object
			// jsonRequest.put("emiId", emiID);// pass this field if you have an
			// EMI Id associated with the transaction
			jsonRequest.put("tipAmount", 0.00);// optional
			jsonRequest.put("image", jsonImageObj); // Pass this attribute when you have a valid captured signature image
			jsonRequest.put("txnId", strTxnId);// pass your transaction id value here
			if (strTxnId != null) {
				EzeAPI.attachSignature(this, REQUEST_CODE_ATTACH_SIGN, jsonRequest);
			} else {
				displayToast("Inorrect txn Id, please pass txnId");
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Check For Updates method is only relevant in the Android platform. It is
	 * invoked to check for any updates to the Android Service app.
	 */
	private void doCheckUpdate() {
		EzeAPI.checkForUpdates(this, REQUEST_CODE_UPDATE);
	}

	/**
	 * use this method to check the status of an incomplete transaction due to
	 * timeouts, network errors etc.
	 */
	private void doCheckIncompleteTxn() {
		EzeAPI.checkForIncompleteTransaction(this, REQUEST_CODE_GET_INCOMPLETE_TXN);
	}

	/**
	 * Retrieve the details of a transaction given a transaction Id
	 */
	private void doGetTxnDetails() {
		if (!strTxnId.equals(null)) {
			EzeAPI.getTransaction(this, REQUEST_CODE_GET_TXN_DETAIL, strTxnId);// pass your reference id value here
		} else {
			displayToast("Inorrect txn Id, please pass txnId");
		}
	}

	/**
	 * closes the connection with Ezetap server and shut down gracefully
	 */
	private void doCloseEzetap() {
		EzeAPI.close(this, REQUEST_CODE_CLOSE);
	}

	/**
	 * @param message
	 *            message for Toast
	 */
	private void displayToast(String message) {
		Toast.makeText(this, message, Toast.LENGTH_LONG).show();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		try {
			if (intent != null && intent.hasExtra("response")) {
				Toast.makeText(this, intent.getStringExtra("response"), Toast.LENGTH_LONG).show();
				Log.d("SampleAppLogs", intent.getStringExtra("response"));
			}
			switch (requestCode) {
				case REQUEST_CODE_CASH_TXN:
				case REQUEST_CODE_CASH_BACK_TXN:
				case REQUEST_CODE_CASH_AT_POS_TXN:
				case REQUEST_CODE_WALLET_TXN:
				case REQUEST_CODE_SALE_TXN:

					if (resultCode == RESULT_OK) {
						JSONObject response = new JSONObject(intent.getStringExtra("response"));
						response = response.getJSONObject("result");
						response = response.getJSONObject("txn");
						strTxnId = response.getString("txnId");
						emiID = response.getString("emiId");
					} else if (resultCode == RESULT_CANCELED) {
						JSONObject response = new JSONObject(intent.getStringExtra("response"));
						response = response.getJSONObject("error");
						String errorCode = response.getString("code");
						String errorMessage = response.getString("message");
					}

					break;

				default:
					break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @return transaction id is valid
	 */
	private boolean isTransactionIdValid() {
		if (strTxnId == null)
			return false;
		else
			return true;
	}

	private void openTXNIdEnterPopup(final int requestCode) {
		try {
			LayoutInflater layoutInflater = LayoutInflater.from(EzeNativeSampleActivity.this);
			final View customView = layoutInflater.inflate(R.layout.txn_id_enter_popup, null);
			AlertDialog.Builder editCustomerPopup = new AlertDialog.Builder(EzeNativeSampleActivity.this);
			editCustomerPopup.setCancelable(false);
			editCustomerPopup.setView(customView);
			final AlertDialog alertDialog = editCustomerPopup.create();
			alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
			alertDialog.show();

			Button cancelButton = (Button) customView.findViewById(R.id.cancel_button);
			cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					alertDialog.cancel();
				}
			});

			final EditText txnIdEditText = (EditText) customView.findViewById(R.id.txn_id_number);
			Button confirmButton = (Button) customView.findViewById(R.id.confirm_button);
			confirmButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					strTxnId = txnIdEditText.getText().toString() + "";
					switch (requestCode) {
						case REQUEST_CODE_VOID:
							doVoidTxn();
							break;
						case REQUEST_CODE_GET_TXN_DETAIL:
							doGetTxnDetails();
							break;
						case REQUEST_CODE_ATTACH_SIGN:
							doAttachSignature();
							break;
					}
					alertDialog.cancel();
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void openPaymentPayloadPopup(final int REQUEST_CODE) {
//		try {
//			LayoutInflater layoutInflater = LayoutInflater.from(EzeNativeSampleActivity.this);
//			final View customView = layoutInflater.inflate(R.layout.payment_payload_popup, null);
//			AlertDialog.Builder editCustomerPopup = new AlertDialog.Builder(EzeNativeSampleActivity.this);
//			editCustomerPopup.setCancelable(false);
//			editCustomerPopup.setView(customView);
//			final AlertDialog alertDialog = editCustomerPopup.create();
//			alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//			alertDialog.show();
//
//			Button cancelButton = (Button) customView.findViewById(R.id.cancel_button);
//			cancelButton.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					alertDialog.cancel();
//				}
//			});
//
//			final EditText customerNameEditText = (EditText) customView.findViewById(R.id.user_name);
//			final EditText emailIdEditText = (EditText) customView.findViewById(R.id.user_email);
//			final EditText mobileNumberEditText = (EditText) customView.findViewById(R.id.user_mobile);
//			final EditText orderNumberEditText = (EditText) customView.findViewById(R.id.order_number);
//			final EditText payableAmountEditText = (EditText) customView.findViewById(R.id.payable_amount);
//			final EditText cashBackAmountEditText = (EditText) customView.findViewById(R.id.cashback_amount);
//
//			Button confirmButton = (Button) customView.findViewById(R.id.confirm_button);
//			confirmButton.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					if (orderNumberEditText.getText().toString().equalsIgnoreCase("")
//							|| payableAmountEditText.getText().toString().equalsIgnoreCase("")) {
//						displayToast(mandatoryErrMsg);
//						return;
//					}
					try {
						JSONObject jsonRequest = new JSONObject();
						JSONObject jsonOptionalParams = new JSONObject();
						JSONObject jsonReferences = new JSONObject();
						JSONObject jsonCustomer = new JSONObject();

						//Amount (mandatory)
						jsonRequest.put("amount", "120");

						// Building Customer Object(Optional)
						jsonCustomer.put("name", "sdfdsg");
						jsonCustomer.put("mobileNo", "9876543210");
						jsonCustomer.put("email", "fdsf@ffs.com");
						jsonOptionalParams.put("customer", jsonCustomer);

						// Building References Object(Optional)
						// Additionally reference2 and reference3 can be used as well
						jsonReferences.put("reference1", "122454");

						// Passing Additional References(Optional)
						// If reference1, reference2 & reference3 is insufficient then additionalReferences array can be used
						JSONArray array = new JSONArray();
						array.put("addRef_xx1");
						array.put("addRef_xx2");
						jsonReferences.put("additionalReferences", array);

						jsonOptionalParams.put("references", jsonReferences);

						// Building Optional params Object(Optional)
						//jsonOptionalParams.put("amountCashback", cashBackAmountEditText.getText().toString() + "");// Cannot

						// Tip (Optional)
						//jsonOptionalParams.put("amountTip", 0.00);

						// Pay to Account(Optional) - Used for Multi TID payments
						//jsonOptionalParams.put("payToAccount", "12322");

						//Additional Data(Optional) - Used to send any additional info
						//Rarely used and limited for Ezetap's internal use
						JSONObject addlData = new JSONObject();
						addlData.put("addl1", "addl1");
						addlData.put("addl2", "addl2");
						addlData.put("addl3", "addl3");
						//jsonOptionalParams.put("addlData", addlData);

						//Application Data(Optional) - Used to send any app info
						//Rarely used and limited for Ezetap's internal use
						JSONObject appData = new JSONObject();
						appData.put("app1", "app1");
						appData.put("app2", "app2");
						appData.put("app3", "app3");
						//jsonOptionalParams.put("appData", appData);

						// Building final optional params
						jsonRequest.put("options", jsonOptionalParams);


						switch (REQUEST_CODE) {
							case REQUEST_CODE_WALLET_TXN:
								doWalletTxn(jsonRequest);
								break;
							case REQUEST_CODE_CHEQUE_TXN:
								// Building Cheque Object
								JSONObject jsonCheque = new JSONObject();
								jsonCheque.put("chequeNumber", "");
								jsonCheque.put("bankCode", "");
								jsonCheque.put("bankName", "");
								jsonCheque.put("bankAccountNo", "");
								jsonCheque.put("chequeDate", "");

								jsonRequest.put("cheque", jsonCheque);

								doChequeTxn(jsonRequest);
								break;
							case REQUEST_CODE_SALE_TXN:
								jsonRequest.put("mode", "SALE");//Card payment Mode(mandatory)
								doSaleTxn(jsonRequest);
								break;
							case REQUEST_CODE_CASH_BACK_TXN:
								jsonRequest.put("mode", "CASHBACK");//Card payment Mode(mandatory)
								doCashbackTxn(jsonRequest);
								break;
							case REQUEST_CODE_CASH_AT_POS_TXN:
								jsonRequest.put("mode", "CASH@POS");//Card payment Mode(mandatory)
								doCashAtPosTxn(jsonRequest);
								break;
							case REQUEST_CODE_CASH_TXN:
								doCashTxn(jsonRequest);
								break;
						}
//						alertDialog.cancel();
					} catch (Exception e) {
						e.printStackTrace();
					}
//				}
//			});
//			alertDialog.show();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		finish();
	}
}
