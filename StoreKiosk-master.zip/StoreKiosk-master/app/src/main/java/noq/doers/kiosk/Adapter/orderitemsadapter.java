package noq.doers.kiosk.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import noq.doers.kiosk.Model.orderitemsmodel;
import noq.doers.kiosk.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class orderitemsadapter extends BaseAdapter {
    List<orderitemsmodel> orderitemsList;

    Context context;
    private static LayoutInflater inflater=null;
    public orderitemsadapter(Context context, List<orderitemsmodel> orderitemsList) {
        // TODO Auto-generated constructor stub
        this.context = context;
        this.orderitemsList = orderitemsList;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return orderitemsList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView item_name,qty,rate,amount;
        ImageView itm_img;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView=convertView;

        if (rowView == null) {
            rowView = inflater.inflate(R.layout.list_orditem, null);

            holder.item_name =(TextView) rowView.findViewById(R.id.itmname);
            holder.itm_img = rowView.findViewById(R.id.itm_img);
            holder.qty =(TextView) rowView.findViewById(R.id.itmqty);
            holder.rate =(TextView) rowView.findViewById(R.id.itmrate);
            holder.amount =(TextView) rowView.findViewById(R.id.itmamnt);

            rowView.setTag(holder);
        } else {
            holder = (Holder) rowView.getTag();
        }
        //getting the hero of the specified position
        orderitemsmodel order = orderitemsList.get(position);

        holder.item_name.setText(order.getItem_name());
        holder.qty.setText(order.getQty()+" Items");
        holder.rate.setText(order.getRate());
        holder.amount.setText(order.getAmount());
        Picasso.get()
                .load(order.getImage())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into( holder.itm_img);

        return rowView;
    }


}